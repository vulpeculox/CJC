// Settings for class viewer including cfg packages (putputs) and source roots (inputs)


//==============================================================
//==============================================================
class CcvCfg_package{
  constructor(Name,Classes,Requires){
    this.id = -1;  // automaticlly added when indexing
    this.name = Name;
    this.roots = [];          // array of source root doublets [path,regexp]
    this.classes = Classes;   // array of class names
    this.needs = [];          // array of calculated dependencies
    this.alsoNeeds = Array.isArray(Requires) ? Requires : [];  // array of manually specified dependencies
    this.notes = '';   // string of waffle
    this.isCurrent = false;   // true if this is current package
    this.dlFormat = 'JS';  // alternative is 'HTML'
  }
  
  DependsListing(){
    var na = this.alsoNeeds.slice();
    na.concatExtra(this.needs);
    switch(this.dlFormat){
    case 'JS' : return  na.map(V=>"'"+V+"',").join('\n');
    case 'HTML' : return  na.map(V=>'&lt;script src="'+V+'"&gt;&lt;/script&gt;').join('\n');
    default : return 'impossible';
    }    
  }
  
  // JSorHTML can be "JS" "HTML" or null for switch
  //-----------------------------------------------
  SetDlFormat(JSorHTML){
    if(typeof JSorHTML == 'undefined'){
      this.dlFormat = (this.dlFormat=='HTML') ? 'JS' : 'HTML';
    }else{  
      this.dlFormat = (JSorHTML.toUpperCase()=='JS') ? 'JS' : 'HTML';
    }  
  }

  
  // Html for a list item
  Li(){
    
    // alternatives for current package
    var current,cl;
    if(this.isCurrent){
      current = ' <span class="tick1 bgyel">This is the current package </span>';
      cl = ' class="liPackage frame1 bggrn" ';
    }else{
      current = ' <span class="m1 button" title="Work with" onclick="SelectPack(\''+this.id+'\');">Make this the <span class="pin">working</span> project </span>';
      cl = ' class="liPackage frame1" ';
    }  
    // alternatives for dependency list
    var dlTitle,dlFiles;
    if(this.needs.length<1){
      dlTitle = 'No dependencies.  Best you refresh to make sure!';
      dlFiles = '';
    }else{  
      dlTitle = 'Cut and paste for Javascript use';
      dlFiles = this.DependsListing();
    }  
    
    var excl = '';
    if(this.name == '??'){
      excl = 'frame2 red blob';
    }  
    var topdiv = 
    '<div class=packDiv id="'+this.id+'">'+
      '<div>Package name : <span contenteditable=true class="namePackage bold '+excl+'" title="Can be changed if you want">'+this.name+'</span>'+
      current + '<span class="button m1 buPackDelete">Delete</span></div><br>'+
    '</div>';
    
    var rootsTable = '<table class="boxed">'+this._RootsTrs()+'</table>';
    
    var middiv = 
    '<div class="split half">'+
      '<div><table>'+
        '<tr><td title="Paths to source files">Roots</td><td>'+rootsTable+'</td></tr>'+
        '<tr><td>Classes</td><td><textarea class="packClasses" cols=40 rows=3 title="Class names split by spaces.  Click on class listing or source tree to populate.">'+this.classes.join(' ')+'</textarea></td></tr>'+
        '<tr><td>Extra</td><td><textarea class="packExtra" title="File names CV might not know about.  One per line" cols=40 rows=3>'+this.alsoNeeds.join('\n')+'</textarea></td></tr>'+
        '<tr><td>Notes</td><td><textarea class="packNotes" title="Any text" cols=40 rows=2>'+this.notes+'</textarea></td></tr>'+
      '</table></div>'+
      '<div><div><span class="bgblu">Computed dependencies</span><br>'+
          '<span class="button">Refresh</span> '+
          '<span class="button" onclick="SwitchNeedsFormat(\''+this.id+'\');">Switch format</span></div>'+
        '<div class="code" title="'+dlTitle+'">'+dlFiles+'</div>'+
      '</div>'+  
    '</div>';    
        
    
    return '<li id="'+this.id+'" ' + cl + '>'+topdiv+middiv;
              
  }

  // Toggle the .isCurrent flag depending on whether the
  //  ProjName matches this project
  //----------------------------------------------------
  FlagCurrent(Id){
    this.isCurrent = (this.id == Id);
  }
  
    
}

//==============================================================
//==============================================================
class CcvCfg_package_index extends Cindex{
  
  constructor(){
    super('AUTOMATIC');
  }

  SetCurrent(Id){
    this.records.forEach(P=>P.FlagCurrent(Id));
  }  
  
  // if not found then return false
  GetCurrent(){
    return this.Find(P=>P.isCurrent);
  }  
  
  // HTML for editing packages
  HTML(){
    var liadd='<li class="liPackage bgyel center">'+
      '<div class="frame1 bgpnk padtb round1">'+
      '<span class="button" onclick="NewPackage();">Add new package</span>'+
      '<span id="buClosePackMaint" class="m1 button" onclick="EndPackMaint();">End package maintenence</span>'+
      '</div>';
    var lis = this.records.map(P=>P.Li());
    return '<ul class="bare">'+liadd+lis.join('\n\n\n')+'</ul>';
  }  
  
  AddNew(){
    this.Add(new CcvCfg_package('??',[],[]));
    if(this.records.length==1){
      this.records.isCurrent = true;
    }else{  
      // place at top of list
      var r = this.records.pop();   // take off the end
      var k = this._keys.pop();
      this.records.unshift(r);      // put on front
      this._keys.unshift(k);
    }    
  }  
  
}  

//==============================================================
//==============================================================
/*  Will eventually refactor    
class CcvCfg_roots_root{
  constructor(Name,PathsArray){
    this.name = Name;
    this.paths = PathsArray;
  }
}
  
class CcvCfg_roots{
  constructor(){
    super('name');
  }
}
*/
     
    
//==============================================================
//==============================================================
class CcvCfg{
  constructor(){
    // defaults
    this.freshen = false;
    this.codeRoots = [];  // will be array of strings (Hierarchy as in settings example)
    this.selectedRoots = [];  // array of rootGroupNames 
    this.sourceNameMatcher = 'C\w+';    // C....js files only
    this.ignoreSources = [];  // will be array of strings
    this.packages = new CcvCfg_package_index();  // output projects based on classes
    this.store = null;
    this.storeKey = '';
    this.reportFormat = 'Brief';
    this.lastSourceView = 'Tree';
  }
  
  
  //========== ROOT GROUPS ==============  

  // Array of group names  
  //. Group names start with letter or digit
  //--------------------------------------------
  get rootNames(){
    var rx = /^\w+/;
    return this.codeRoots.filter(V=>rx.test(V));
  }  
  
  // return array of doublets [name,boolean]
  //  indicating if selected
  //----------------------------------------
  get rootsWithSelectionStatus(){
    return this.rootNames.map(function(R){
      return [R,this.selectedRoots.includes(R)];
    },this);
  }
  
  // Return an array of [path,regex] for all selected 
  //-------------------------------------------------
  get selectedRoot(){
    var rv = [];
    this.selectedRoots.forEach(function(N){
      rv.concatExtra(this.GetRootsForName(N));
    },this);
    rv.sort();
    return rv;
  }

  
  // return array of [path,regex] matching group
  //. paths start with . or / 
  //--------------------------------------------
  GetRootsForName(Name){
    var gotName = false;
    var paths = [];
    var cr = this.codeRoots.slice();  // working array
    while(cr.length>0){   // like this 'cos we want to break out
      var l = cr.shift();
      if(!gotName){    // looking for name to start us off collecting
        if((''+l).startsWith(Name)){gotName=true;}  // and onto next line
      }else{
        if(/^\w+/.test(l)){break;}  // start of another group
        paths.push(l);
      }
    }
    return this._PathsToPathAndRegEx(paths);
  }
  
  // Convert array of strings looking like " /path/etc/ , regEx string" into
  //  an array of doublets [path-string,actual regexp]
  //------------------------------------------------------------------------
  _PathsToPathAndRegEx(Paths){
    return Paths.map(function(V){
      var a = V.split(',');
      var p = a[0].trim();
      var r = 'js';
      if(a.length>1){
        try{ 
          r = new RegExp(a[1].trim()) ;
        }
        catch(e){  
          throw 'Can\'t make regular expression from "'+a[1]+'" ('+a[0]+')';
        }
      }
      return [p,r];
    });  
  }
  
  
  
  
  // Display list of packages
  //-------------------------  
  PackageListing(){
    return this.packages.HTML();
  }
  
  NewPackage(){
    this.packages.AddNew();
  }
  
  // Id of -1 for none set
  SetCurrentPackage(Id){
    this.currentPackageId = Id;
    return this.packages.SetCurrent(Id);
  }  
  
  // return false if none
  GetCurrentPackage(){
    return this.packages.GetCurrent();
  }   
      
      
  GetPackageByName(Name){
    return this.packages.Find('name',Name);
  }
  GetPackageById(Id){
    return this.packages.Get(Id);
  }
  UpdatePackage(Id,Obj){
    var rv = this.packages.Update(Id,Obj);
    this.Save();
    return rv;
  }  
  DeletePackage(Id){
    var rv = this.packages.Delete(Id);
    this.Save();
    return rv;
  }  

  Save(){
    this.store.Put(this.storeKey,this);
  }  
  
  // regex for matching source files
  //--------------------------------  
  SourceMatcherRegEx(){
    return new RegExp('^'+v+'\.js');
  }  
  
  // Return display value for the Element
  //----------------------------------------------------------
  GetDisplay(Element){
    var v = this[Element];
    if(typeof v != 'undefined'){
      switch(Element){
      case 'freshen' : return v;   // simple boolean
      case 'sourceNameMatcher' : return v; // inner part of reg ex string
      case 'codeRoots' : return v.join('\n');  // lines split by cr      
      case 'ignoreSources' : return v.join('\n');  // lines split by cr      
      }
    }      
  }
  
  //----------------------------------------------------------
  get packageNames(){
    return this.packages.Singlets('name');
  }  

  GetPackage(Name){
    return this.packages.Find('name',Name);
  }  
  

  // read some value of an input into one of the cfg elements
  // return an error message or empty string
  //----------------------------------------------------------
  TakeInput(Element,InputVal){
    var v,ca=[],sa=[],p='',c='',n='',ps=[];
    var msg='';
    switch(Element){
    case 'freshen' :
            v = InputVal;
            if(typeof v != 'boolean'){msg = 'cfg/freshen needs a boolean';}
            break;  
    case 'sourceNameMatcher' :
            v = InputVal.trim();
            if(v===''){v = 'C\w+';}
            var rs = '^'+v+'\.js';
            try{
              var rx = new RegExp(rs);
            }catch(e){
              msg = 'When combined to /'+rs+"/ this isn't a legal regular expression.";
            }
            break;
    case 'codeRoots' :
            v = InputVal.split('\n').map(V=>V.trim()).filter(V=>(V!==''));
            v = v.map(V=>V.replace(/^\./,'  .')).map(V=>V.replace(/^\//,' /'));
            break;
    case 'ignoreSources' :
            v = InputVal.split('\n').map(V=>V.trim()).filter(V=>(V!==''));
            break;
    default :
            msg = 'Unknown element name';     
    }
    // finished twiddling inputs into internal format
    // We may have an error though!
    if(msg === ''){
      this[Element] = v;
    }
    
    return msg;   // error or nul string == OK
  }
  
    
}


CJC.RegisterConstructors([CcvCfg,CcvCfg_package,CcvCfg_package_index]);  
