  

// GLOBALS
//-----------------------------------------------

var codeRoots = [               // paths to monitor
  '/test/2018/',
  '/test/2017/UI/classes/'
];

/*   for cfg root settings when lost
2018
  /test/2018/', ^C\w+\.js
UI
  /test/2017/UI/classes/', ^C\w+\.js

*/
var sourceNameMatcher = /^C\w+\.js/;    // C....js files only

var filesLoaded = false; 
var aq;   // async queue 
var fr = new CfileReader(this);
var ls = new ClocalStore('ClassViewer');
//ls.Delete('config');
//ls.Delete('classIndex');
//ls.Delete('sourceIndex');
var cfg = ls.GetOrCreate('config',CcvCfg);
    if(cfg.codeRoots.length===0){cfg.codeRoots = codeRoots;}
var cix = ls.GetOrCreate('classIndex',CclassIndex);
var six = ls.GetOrCreate('sourceIndex',CsourceIndex);

var tr = new Ctree('tree',{onClickDo:TreeClicked});
var mus;  // Cmenus

var class_List;            // array of names to be shown in class listing  
var source_dep_list = [];  //  array of sources in dependency order
// packages
var class_pick_dest = false;   // might be a textarea elemnt to send clicked-on classes to
var id_editing = false;        // package being edited
var maintaining_packages = false;   // are we showing the pack maint screen
var current_class = false;     // class obj being displayed or false 
var nameFilter = '';           // lower case filter
var delayBeforeFilter;         // handle to filtering delay

// set up autoreload and load tree
//--------------------------------
$(document).ready(function(){
  var ar = AutoReload.Start({latencyId:"ARtimer"});   // NB set watched in links etc
  ShowMessage('Initialising');
  InitialiseMenus();
  InitialiseView();
  PopulateCfgPage();
  ShowSources();
});

// Set up the display controls and latches for which roots are on show
//--------------------------------------------------------------------
function InitialiseView(){
  // DISPLAY OPTIONS
  var selDo = new Cselect('displayOptions','selTreeView','Sources','Tree,Alphabetically,Hidden','How should sources be displayed',DispOptClicked);
  var selRf = new Cselect('displayOptions','selRepFmt','Report format','Brief,Full,User','Reporting style',DispOptClicked);
  var selRi = new Cselect('displayOptions','selRepInclude','Report include','All inherited,Exclude inherited,Whole file','Which elements to include',DispOptClicked);
  
  selDo.SetOption(cfg.lastSourceView);
  selRf.SetOption(cfg.reportFormat);
  selRi.SetOption(cfg.reportInclude);
  $('#filterStr').on('keyup',OnChangeFilter);
  
  // ROOTS  (need to read cfg and set)
  var rwss = cfg.rootsWithSelectionStatus;  //[name,bool] doublets
  rwss.forEach(function(NB){
    var l = new Clatch('sourceLatches',NB[0],NB[0],'',false,SourceLatchClicked);
    l.SetState(NB[1]);
  });  
  
  HideReport();
  ShowSourceView();
  
  $('#alpha').on('click','span',HandleAlphaClicked);
  $('#classes').on('click','span',HandleClassNameClicked);
  
  
}

function OnChangeFilter(Ev){
  var inp = $(Ev.target);
  var str = inp.val();
  nameFilter = str.trim().toLowerCase();
  if(delayBeforeFilter){clearTimeout(delayBeforeFilter)};
  if(nameFilter.length>2){
    delayBeforeFilter = setTimeout(ExecuteFilter,500);
  }
  if(nameFilter.length===0){
    ExecuteFilter();
  }
  
}
function ExecuteFilter(){
  clearTimeout(delayBeforeFilter);
  //console.log('execute filter',nameFilter);
  $('#alpha').html(six.HTMLAlphaNames(nameFilter));
  ShowClasses('',six.MatchingNames(nameFilter));
}  
  
  

  
// display tree oralphabetical list according to cfg.lastSourceView
function ShowSourceView(){
  if(cfg.lastSourceView == 'Tree'){
    $('div#tree').removeClass('hidden');
    $('div#alpha').addClass('hidden');
  }else{
    $('div#alpha').removeClass('hidden');
    $('div#tree').addClass('hidden');
  }
}
function HideSourceView(){
  $('#tree,#alpha').addClass('hidden');
}  


// Handle changes to the display options
//--------------------------------------
function DispOptClicked(Select){
  switch(Select.id){
  case 'selTreeView' : 
    switch (Select.selected){
    case 'Tree'           : cfg.lastSourceView = Select.selected;
                            ShowSourceView();
                            break;
    case 'Alphabetically' : cfg.lastSourceView = Select.selected;
                            ShowSourceView();
                            break;
    case 'Hidden'         : HideSourceView();
                            break;
    }
    $('#report').addClass('hidden');
    ShowSources();
    cfg.Save();
    break;
  case 'selRepFmt' :
          cfg.reportFormat = Select.selected;
          ReportClass(current_class);
          cfg.Save();
          break;
  case 'selRepInclude' :    
          cfg.reportInclude = Select.selected;
          ReportClass(current_class);
          cfg.Save();
          break;
  }
}
  
// Flip the selection of some source roots
function SourceLatchClicked(Latch){
  //console.log('rc',Latch.id,Latch.isDown);
  var p = cfg.GetPackageByName(Latch.id);
  if(Latch.isDown){
    cfg.selectedRoots.append(Latch.id);
  }else{
    cfg.selectedRoots.remove(Latch.id);
  }
  cfg.Save();
  ShowSources(true);
}
  
  
// Load tree with sources and also alphabetical list
// Display as appropriate
// Force reload may be true to rescan 
function ShowSources(ForceReload){
  var roots = cfg.selectedRoot;
  if(roots.length<1){roots = codeRoots;}
  //console.log('ROOTS\n',roots.join('\n'));
  //@@@ this switch may need kicking
  ShowMessage('Finding source files');
  if(ForceReload){filesLoaded = false;}
  if(filesLoaded===false){tr.LoadFromRoots(roots,sourceNameMatcher,AllRead);}  
}
// after all sources loaded 
function AllRead(){
  // message on:updating sources
  // foreach tr.
  //   in store?
  //     newer?
  //      add to todo list
  //  fr.ReadFiles(todo,ProcessCfile,AllSourcesUpdated);
  
  
  //console.log('All source files loaded');
  tr.FlattenAlphabetically('alpha');
  
  var fnames = tr.GetAllFiles();    //[name,full name]
  var newer = fnames.filter(function(N){         //[name,full name,last mod]
    var lm = CfileReader.LastModified(N[1]);     // file stamp
    var srce = six.Get(N[1]);                    // stored info
    if(!srce){
      //console.log('missing',N[1]);
      return true;
    }else{
      var newer = (srce.parseTimestamp.getTime() < lm.getTime());
      //if(newer){console.log('newer',N[1],srce.parseTimestamp.getTime(),lm);}
      //if(srce.fileName.includes('ScriptO')){console.log('scripto',N[1],'\nLast Parsed   :'+srce.parseTimestamp+' '+srce.parseTimestamp.getTime()+'\nSource changed:'+lm+' '+lm.getTime());}
      return newer;
    }      
  });  
  newer = newer.map(N=>N[1]);   // full name
  //console.log('changed\n',newer.join('\n'));
  ShowMessage('Reading changed sources');
  fr.ReadFiles(newer,ProcessCfile,AllClickedRead);
  
  
  //six.GenAllNeeded(cix); // make sure dependencies are up to date
}



var processing_list = [];

// Clicked on tree comes here
// Read the file then process        
// Special case if we're trying to populate package classes
//  which depends of flag hunting_for_packages.
//--------------------------------------------------------
function TreeClicked(Fname,RowIx,IsDir){
  if(class_pick_dest !== false){
    PickSourcesForPackages(Fname,RowIx,IsDir);
    return;
  }  
  if(id_editing !== false){UpdatePackage();}
  if(maintaining_packages){$('#buClosePackMaint').click();}
 
  // otherwise highlight classes
  var sources = (! IsDir) ? [Fname] : tr.ChildFiles(RowIx);  //[string]
  HighlightClassesForSources(sources);
}

// clicked on alpha list comes here
// Show classes in this source
//---------------------------------
function HandleAlphaClicked(Ev){
  var el = $(Ev.target);
  var sname = el.attr('title');
  el.parent().children('span').removeClass('bgpnk bgbrn');
  HighlightClassesForSources([sname]);
  el.addClass('bgpnk');  
  
}
  

// String of source names to class highlighting
function HighlightClassesForSources(Sources){
  $('#report').addClass('hidden');
  var classes = FindClassNamesForSources(Sources);  // [string]
  var clElements = $('#classes span');
  clElements.each(function(I,E){
    var el = $(E);
    var inSources = classes.includes(el.text());
    el.toggleClass('bgpnk',inSources).removeClass('bgbrn bglime');
  });  
}

function AllClickedRead(){
  //console.log('All clicked source files loaded');
  ShowSourceView();
  HideMessage();
  six.Save();
  ShowClasses();
}

  

// Process a class file
// Return false if errors
//------------------------------------
function ProcessCfile(SourceText,FileName){
  var cl = new CclassFileParser(FileName);
  var ok = cl.ParseSource(SourceText);
  if(!ok){
    var r = cl.parseErrors.map(function(V){
      return '<li><span class="bgpnk">'+V[0]+'</span> '+V[1];
    });
    var src = '<div class=h3>'+FileName+'</div>';
    $('#report').html(src+'<ul>'+r.join('\n')+'</ul>').removeClass('hidden');    
    return false;
  }else{
    // OK so update our records
    cl.classes.forEach(function(V){
      cix.Add(V,true);
    });
    cix.Save();
    var s = cl.ExportSource();
    six.Add(s,true);
    six.Save();
    return true;
  } 
  
}


function WipeIndex(){
  mus.CloseCurrent(true);
  cix.Wipe('YES');
  six.Wipe('YES');
  ShowClasses();
}

  
  
// Filter is string or array of class names or 'ALL'
//  or undefined for all in source tree.
// AdditionalSources can be an array of class names to have
//  in addition.  This is used when filtering produces a source
//  that matches the filter which may contain classes which don't.
//----------------------------------------- 
function ShowClasses(Filter,AdditionalSources){
  var filt = Filter || 'ALL';
  var cns = cix.ClassNames(nameFilter).sort();      // class names
  var clist = [];
  if(typeof filt == 'string'){
    if((filt == 'ALL')||(filt==='')){
      clist = cns.slice();
    }else{  
      clist = cns.filter(V=>V.includes(Filter));
    }  
  }else{  
    if(Array.isArray(filt)){
      var f = filt.slice();
      clist = cns.filter(V=>Filter.includes(V));
    }else{
      var snames = tr.GetAllFiles();   // [name,fullname]
      clist = FindClassNamesForSources(snames);
    }
  }

  // we may have sources matching a filter but the class names
  // don't.  So we'll add in all classes from those matching sources
  //console.log('as',AdditionalSources);
  
  if(Array.isArray(AdditionalSources)){
    clAddnl = FindClassNamesForSources(AdditionalSources);
    clist.concatExtra(clAddnl);
  }  
  ShowClassList(clist);
}

// Return a list of class names included in the sources provided  
// SourcesOrNames is an array either of source objects or filenames or
// [name,filename]
function FindClassNamesForSources(SourcesOrNames){
  var ss = SourcesOrNames.slice();
  if(ss.length<1){return [];}
  if(typeof ss[0]=='string'){  // names of sources
    ss = ss.map(function(N){
      return six.Get(N);
    });  
  }else{
    if(Array.isArray(ss[0])){
      ss = ss.map(function(NF){
        return six.Get(NF[1]);
      });  
    }
  }    
  // ss must now be an array of sources
  var rv = [];
  ss.forEach(function(S){
    rv.concatExtra(S.classNames);
  });
  return rv;
}
  


  
  
/*function ClearClassList(){
  class_List = [];
}
function AddToClassList(Cname){
  class_List.push(Cname);
}*/


function ShowClassList(ClassNames){
  if(ClassNames.length<1){
    $('#classes').html('').addClass('hidden');
    return;
  }  
  var cands = ClassNames.map(function(N){    
    var c = cix.Get(N);
    return [N,c.sourceFile,c.comments.join('').substr(0,60)];
  });  
  if(nameFilter != ''){   // always l/case
    cands = cands.filter(NSC=>(NSC.join('').toLowerCase().includes(nameFilter)));
  }    
  var spans = cands.map(function(NSC){
    var t = 'title="'+NSC[1]+'\n'+NSC[2].trim()+'"'; 
    return '<span '+t+'>'+NSC[0]+'</span><br>';
  });  
  var h = spans.join('\n');
  $('#classes').html(h).removeClass('hidden');
}  

 

function ReportSource(Ev){
  var slName = $(Ev.target).text();
  $('#report').html(six.ReportSource(sName,cix)).removeClass('hidden')();
}

  
  
function TrawlForChanged(){
  var sfs = tr.ChildFiles(0);
  var newerSources = sfs.filter(function(V){
    var needsParsing = true;
    var s = six.Get(V);
    if(s){
      var fileModDate = CfileReader.LastModified(V);
      needsParsing = fileModDate > s.parseTimestamp;
    }  
    return needsParsing;
  });
  fr.ReadFiles(newerSources,ProcessCfile,AllUpToDate);
}
  
function AllUpToDate(){
  six.Save();
  cix.Save();
  //console.log('All up to date');
  ShowClasses();
}
  
function ExpandSourceComments(Bu){
  var bu = $(Bu);
  var dp = bu.parent();
  var db = dp.children('div');
  bu.remove();
  db.removeClass('hidden');
}

// class name clicked
// do report, highlight associated classes and sources
//----------------------------------------------------
function HandleClassNameClicked(Ev){
  // clear all source and class highlights
  $('#classes span').removeClass('bglime bgbrn');  
  $('#alpha span').removeClass('bgpnk bgbrn');
  $('#tree span.flistFile').removeClass('bgpnk bgbrn');
  
  // get the class object
  var el = $(Ev.target);
  var cname = el.text();
  var cl = cix.Get(cname);
  current_class=cl;
  if(!cl){return;}  // can never happen
  // do the report
  ReportClass(cl);
  // highlight associated sources and classes  
  el.addClass('bglime');  // this class
  var rc = cl.RequiresClasses();
  if(rc.length>0){
    $('#classes span').each(function(I,E){
      var e = $(E);
      e.toggleClass('bgbrn',rc.includes(e.text()));
    });
  }
  var rs = cix.ClRequiresSources(cl.name);
  if(rs.length>0){
    $('#alpha span').each(function(I,E){
      var e = $(E);
      e.toggleClass('bgbrn',rs.includes(e.attr('title')));
    });
    $('#alpha span.flistFile').each(function(I,E){
      var e = $(E);
      e.toggleClass('bgbrn',rs.includes(e.attr('title')));
    });
  }
}  

// report on a class
//------------------
function ReportClass(Class){
  if((Class instanceof CclassDef)===false){   // trap no current class/silly argument
    HideReport();
    return;
  }  
  current_class = Class;
  var h = '';
  
  // we may have to report on many classes in a single file
  if(cfg.reportInclude=='Whole file'){
    var src = six.Get(current_class.sourceFile);
    var cs = src.Classes(cix);
    //console.log('src',src);
    //console.log('cn',cs.map(C=>C.name).join('|'));
    var creps = cs.map(function(C){
      switch(cfg.reportFormat){
      case 'Brief' :   
        return cix.ClReportSignatures(C.name,cfg.reportInclude);
        break;
      default :  // includes Full
        return cix.ClReportClass(C.name,cfg.reportInclude);
      }
    },this);
    h = creps.join('<hr>');
  }else{  
    // single class (ish)
    switch(cfg.reportFormat){
    case 'Brief' :   
      h = cix.ClReportSignatures(current_class.name,cfg.reportInclude);
      break;
    default :  // includes Full
      h = cix.ClReportClass(current_class.name,cfg.reportInclude);
    }
  }
  $('#report').html(h);
  ShowReport();  
}



  
// flip a tick on a tickbox (search options)  
function FlipTick(Elmt){
  var e = $(Elmt);
  if(e.hasClass('tickBox1')){
    e.removeClass('tickBox1').addClass('tickBox0');
  }else{
    e.removeClass('tickBox0').addClass('tickBox1');
  }    
}

//########################################################################
//     SEARCH
//########################################################################


function StartSearch(){
  $('#search').removeClass('bggrn bgwhi bgpuce').addClass('bgyel');
  HideReport();
  var sstr = $('#srchStr').val().trim();
  var srchClasses = $('#tbClasses').hasClass('tickBox1');
  var srchSources = $('#tbSources').hasClass('tickBox1');
  var srchDepth = $('#tbDepth').hasClass('tickBox1');
  var resultsArray = [];
  
  
  var sresults = [];
  if(srchSources){
    sresults = six.Search(sstr,srchDepth);
    sresults.forEach(function(V){
      var n = V.shift();   // name etc;
      V.forEach(function(A){
        resultsArray.push([n,A[0],A[1]]);
      });
    });
  }

  if(srchClasses){
    sresults = cix.Search(sstr,srchDepth);
    sresults.forEach(function(V){
      var n = V.shift();   // name etc;
      V.forEach(function(A){
        resultsArray.push([n,A[0],A[1]]);
      });
    });
  }

  //@@@ classes will go here
  console.log('xxx',resultsArray.length);
  

  if(resultsArray.length<1){
    $('#search').removeClass('bggrn bgwhi bgyel').addClass('bgpuce');
  }else{  
    $('#search').removeClass('bgpuce bgwhi bgyel').addClass('bggrn');
    var h = '<div class=searchResults>' +
            '<div class=searchTitle>'+sstr+'</div>';
    var rlines = resultsArray.map(function(V){    //[name,type,value]
      var txt = Array.isArray(V[2]) ? V[2].join('<br>') : V[2];
      return '<li><span class="blue">'+V[0]+'</span> '+
                '<span class="green">'+V[1]+'</span> '+
                '<span class="red">'+txt+'</span> ';
    });  
    h += '<ul>'+rlines.join('\n')+'</ul></div>';
    $('#report').html(h).removeClass('hidden');
  }   
  
}

  

// update all the needs for all packages
function UpdateAllNeeds(){
  var pns = cfg.packageNames;
  pns.forEach(V=>Dependable(V));
}  

  
// work out which SOURCES have to come before others  
// PackageName is optional
// Return number unresolved
function Dependable(PackageName){

  HideReport();
  // safety.  source by source dependency generation 
  six.GenAllNeeded(cix);  

  // possibly make master list sequence
  if(source_dep_list.length < 1){
    if(PackageName){
      if(Dependable() >0){return 888;}   
    }  
  }
  
  // Collect all source and the sources they need
  //  in the form of [string filename , array of needed files] 
  // Either all or derrived from package classes etc
  var sns = [];
  var psources = [];   // only need names
  var pack;
  if(PackageName){
    pack = cfg.GetPackage(PackageName);
    if(pack){
      pack.classes.forEach(function(C){
        var ss = cix.ClRequiresSources(C);
        psources.concatExtra(ss);                
      });
    }else{
      $('#report').html('<span class=scream>Package '+PackageName+' not found</span>').removeClass('hidden');
      return 999;
    }        
  }else{  
    sns = six.records.map(function(S){
      return [S.fileName,S.needsSources];
    });
  }    
  
  
  // (For master list only)
  // Loop until source-dependents array is empty or
  //  can't be reduced.  We pull out sources with no
  //  needed sources and remove them from the needed list.
  //  So the needed list should reduce and thus leave more
  //  'nothing needed' to be weeded and so on
  var sourceList = [];
  if(!PackageName){
    var removeCount = 0;
    while(sns.length>0){
      // split into those with and without no dependencies
      var nodeps = sns.filter(V=>(V[1].length<1)).map(S=>S[0]);  // names
      
      // watch for can't resolve all deps
      if(nodeps.length<1){break;}
      
      // add to list of sources
      sourceList = sourceList.concat(nodeps);  
      
      // weed the ones we've just taken
      sns = sns.filter(V=>V[1].length > 0);                        
      
      // weed these from list of dependencies remaining
      sns.forEach(function(S){
        S[1] = S[1].filter(V=>(nodeps.includes(V)===false));
      });
    }    
  }else{
    
    // (For package only)
    // We want the spources listed in the order of the 
    //  master list.
    sourceList = source_dep_list.intersection(psources);
    // update the package
    pack.needs = sourceList.slice();
  }
  
  if(!PackageName){
    source_dep_list = sourceList.slice();
    if(sns.length > 0){
      var h = '<div id=depErrors class="bgpnk frame1 round1">'+
                 '<div class="invert center">Unable to resolve source dependency</div>'+
                 '<ul class="bare">';
      sns.forEach(function(S){
        h += '<li>Source: <span class="bold blue">'+S[0]+'</span> needs:<ul class=bare>\n';
        h += S[1].map(V=>'<li><span class="m2">'+V+'</span>').join('\n');
        h += '</ul>';
      });
      h += '</ul></div>';
      $('#report').html(h).removeClass('hidden');
    }
  }

  
  
  return sns.length;
  
}




//============ display fiddles ============================== 
      
//function ShowHideTree(){$('#tree').toggle();}  
//function ShowHideClasses(){$('#classes').toggle();}  
function ShowConfig(){
  mus.CloseCurrent(true);
  $('#tree,#alpha,#classes').addClass('hidden');
  $('#config').removeClass('hidden');
  var cr = cfg.codeRoots.join('\n');
  if(cr.length<3){cr = '*** REQUIRED *** \n*** See example below';}  
  $('#taCodeRoots').val(cr);

} 
function HideConfig(){$('#config').addClass('hidden');} 
//function ShowHideSearch(){$('#search').toggle();}  
function HideReport(){$('#report').addClass('hidden');}
function ShowReport(){$('#report').removeClass('hidden').removeClass('hidden');}
function ShowMessage(Message){$('#message').html(Message).removeClass('hidden');}
function HideMessage(){$('#message').addClass('hidden');}
  


//########################################################################
//########################################################################
//       CONFIGURATION
//########################################################################
//########################################################################
    
function SaveCfg(){
  $('#saveError').text('').removeClass('scream');
  var e = cfg.TakeInput('codeRoots',$('#taCodeRoots').val());
  if(!e){ 
    e = cfg.TakeInput('sourceNameMatcher',$('#inSourceFilter').val());
    if(!e){
      e = cfg.TakeInput('ignoreSources',$('#taIgnoreSources').val());
      if(!e){
        cfg.TakeInput('freshen',($('#tbFreshen').text()=='Yes'));
        if(!e){
          cfg.TakeInput('packages',$('#taPackages').val());
        }
      }
    }
  }
  if(e){  
    $('#saveError').text(e).addClass('scream');
  }else{
    ls.Put('config',cfg);
    SetRootsMenu();
  }  
}

function AbandonCfg(){
  cfg = ls.Get('config');
  PopulateCfgPage();
  HideConfig();
}
  
function PopulateCfgPage(){
  $('#taCodeRoots').val(cfg.GetDisplay('codeRoots'));
  $('#inSourceFilter').val(cfg.GetDisplay('sourceNameMatcher'));
  $('#taIgnoreSources').val(cfg.GetDisplay('ignoreSources'));
  if(cfg.GetDisplay('freshen')){
    $('#tbFreshen').text('Yes').addClass('tickBox1').removeClass('tickBox0');
  }else{
    $('#tbFreshen').text('No').addClass('tickBox0').removeClass('tickBox1');
  }    
  $('#taPackages').val(cfg.GetDisplay('packages'));
}  
  
function FlipTbFreshen(){
  var e = $('#tbFreshen');
  var ticked = e.hasClass('tickBox1');
  e.removeClass('tickBox1 tickbox0');  
  if(ticked){
    e.text('No').addClass('tickBox0');
  }else{  
    e.text('Yes').addClass('tickBox1');
  }
}

//########################################################################
//########################################################################
//                          MENUS
//########################################################################
//########################################################################

function InitialiseMenus(){
  //--------------------------------------------------------------
  var topMen =
    {
      id:'topMen',
      caption:'',
      autoClose:true,
      rows:[
        ['_Actions','V','actionMen','Wipe local, find changed and settings'], 
        ['_Packages','V',PackageListing,''], 
        ['_Documentation','V',ShowDocumentation,'How to use and interpret results of Class Viewer'] 
      ]
    };  
  //--------------------------------------------------------------
  var actionMen =
    {
      id:'actionMen',
      caption:'Actions',
      autoClose:true,
      rows:[
        ['_Wipe local','V',WipeIndex,'Clear the locally stored data ready for a complete refresh.'], 
        ['Find _changed','V',TrawlForChanged,'Refresh the local data with recent changes'],
        ['_Settings','V',ShowConfig,'Change preferences and tweaks']
      ]
    };  

  //--------------------------------------------------------------
  var depMen =
    {
      id:'depMen',
      caption:'',
      autoClose:true,
      rows:[
        ['_Master sequence','V','',''], 
        ['_HEAD links','V','',''], 
        ['_Js array','V','','']
      ]
    };  
    
    
  //--------------------------------------------------------------
  mus = new Cmenus('mus');
  mus.Add([topMen,actionMen,depMen]);
  mus.SetBurger('.menuBurger','topMen');
  //mus.keyWatcher.Debugging(true);
  SetRootsMenu();
}


function ShowDocumentation(){
  window.open('./documentation.htm','Class Viewer documentation','target="_blank"');
}  

function SetRootsMenu(){
  var rs = cfg.rootsWithSelectionStatus;   
  var menRs = rs.map(function(R){
    var bx = (R[1]) ? 'Box1|Box' : 'Box|Box1';
    return  '<span class="tick['+bx+']">'+R[0]+'</span>';
  });  
  mus.SetList('rootsMen',0,menRs,FlipRootSelect,'');
}  
  
function FlipRootSelect(Event){
  if(Event=='CLOSE'){
    var lt = mus._currentMenu.GetList();
    cfg.selectedRoots = lt.filter(OR=>OR[0]=='Box1').map(V=>V[1]);
    cfg.Save();
  }else{  
    var r = mus.FindClickedRow(Event);
    if(r){
      r.CycleOption();
    }  
  }  
}

  
  
  
//########################################################################
//########################################################################
//     PACKAGE MAINTENANCE
//########################################################################
//########################################################################
var global_temp;

function PackageListing(){
  mus.CloseCurrent();
  UpdateAllNeeds();
  $('#report')
    .html(cfg.PackageListing()).removeClass('hidden')
    .on('focus','.namePackage',EditPackageName)
    .on('blur','.namePackage',AcceptPackageName)
    .on('focus','.packClasses',EnterClassesArea)
    .on('focus','.packExtra,.packNotes',EnterExtraOrNotesArea)
    .on('click','.buPackDelete',DeletePackageStart);
  maintaining_packages = true;
}

function EndPackMaint(){
  UpdatePackage();
  cfg.Save();
  $('#report').addClass('hidden')
    .off('focus','.namePackage')
    .off('blur','.namePackage')
    .off('focus','.packClasses')
    .off('focus','.packExtra,.packNotes')
    .off('click','.buPackDelete');
  maintaining_packages = false;
  
}  
    
  

function NewPackage(){
  cfg.NewPackage();
  PackageListing();
}
  
// event somewhere in list of packages   
function GetPackageIdFromDom(Ev){
  var t = $(Ev.target);
  var li = t.parents('.liPackage').first();
  var id = li.attr('id');
  id = Number.parseInt(id,10);
  id_editing = id;
  return id;
  
}

// find element in package listing  
function GetPackageElement(Id,ElClass){
  var li = $('.liPackage#'+Id);
  var el = li.find('.'+ElClass);
  return el;
}  

// start editing name  
function EditPackageName(Ev){
  UpdatePackage();
  var id = GetPackageIdFromDom(Ev);
  var el = GetPackageElement(id,'namePackage');
  var t = el.text();
  global_temp = t;
  if(t=='??'){
    el.text('').removeClass('blob');
  }  
  el.addClass('bgwhi green frame1 round1');  
}
  
// finish editing name.  Validate  
function AcceptPackageName(Ev){
  var id = GetPackageIdFromDom(Ev);
  var el = GetPackageElement(id,'namePackage');
  var pn = el.text().trim();
  // validate input
  if(pn.length<1){pn='no~name~given';}
  var p = cfg.GetPackageByName(pn);
  if(p){
    if(id != p.id){
      alert('There\'s another package name!');
      pn = global_temp;
    }
  }
  var x = cfg.UpdatePackage(id,{name:pn});
  el.text(pn).removeClass('frame1 green round1 bgwhi frame2 red blob');
}

function ShowPackValError(Id,Msg,Err){
  var trErr = '<tr class="packError"><td class="bgpnk">'+Msg+'</td><td class="red">'+Err+'</td></tr>\n';
  var el = GetPackageElement(Id,'packButs');
  el.before(trErr);
}  
  
function DeletePackageStart(Ev){
  UpdatePackage();
  var id = GetPackageIdFromDom(Ev);
  var elDel = GetPackageElement(id,'buPackDelete');
  elDel.after('<span class="button areYouSure" onclick="DeletePackageFinish('+id+');">ARE YOU SURE</span>');
}

function DeletePackageFinish(Id){
  cfg.DeletePackage(Id);
  id_editing = false;
  $('.areYouSure').remove();
  EndPicking();
  $('#report').html(cfg.PackageListing()).removeClass('hidden');
}

  
function UpdatePackage(){
  var id = id_editing;
  if(id===false){return;}
  var p = cfg.GetPackageById(id);
  if(!p){throw 'Package id='+id+' has gone missing!';}
  var elCl = GetPackageElement(id,'packClasses');
  var elEx = GetPackageElement(id,'packExtra');
  var elNo = GetPackageElement(id,'packNotes');
  var elErr = GetPackageElement(id,'packError');
  if(elErr.length > 0){elErr.remove();}
  
  //validation classes
  var t = elCl.val();
  var a = t.split(/\s+/);
  var err = a.filter(C=>(cix.IdExists(C)===false)).join(' ');
  if(err.length<1){
    p.classes = a;
  }else{
    ShowPackValError(id,'UNKNOWN CLASS',err);
  }
  
  // extras
  t = elEx.val();
  a = t.split(/\n/).map(V=>V.trim()).filter(S=>(S.length>0));
  p.alsoNeeds = a;
  
  t = elNo.val();
  p.notes = t.trim();
  
  cfg.UpdatePackage(id,p);
  id_editing = false;
  
}
  
function EnterClassesArea(Ev){
  UpdatePackage();
  var id = GetPackageIdFromDom(Ev);
  class_pick_dest = GetPackageElement(id,'packClasses');
  $('.buClPick').hide();
  $('#tree,ul.classes').addClass('picking');  
}  

function EnterExtraOrNotesArea(Ev){
  EndPicking();
  UpdatePackage();
  GetPackageIdFromDom(Ev);
}  

function EndPicking(Ev){
  $('#tree,ul.classes').removeClass('picking');  
  class_pick_dest = false;
} 

  
function PickSourcesForPackages(Fname,RowIx,IsDir){
  var ss = (! IsDir) ? [Fname] : tr.ChildFiles(RowIx);
  var cs = [];
  ss.forEach(function(S){
    var s = six.Get(S);
    if(s){cs.concatExtra(s.classNames);}
  });
  AddClassesToPack(cs);
}

function AddClassesToPack(ClassArray){
  var t = class_pick_dest.val();
  var ts = t.split(/\s+/);
  ts.concatExtra(ClassArray);
  class_pick_dest.val(ts.sort().join(' '));
}
  
function SelectPack(Id){
  cfg.SetCurrentPackage(Id);
  EndPackMaint();
}
  
function SwitchNeedsFormat(Id){
  var id = Number.parseInt(Id,10);
  var p = cfg.GetPackageById(id);
  if(p){
    p.SetDlFormat();
    $('#report').html(cfg.PackageListing()).removeClass('hidden');
  }  
}
  
