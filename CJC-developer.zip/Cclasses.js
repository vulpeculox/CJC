// INDEX OF CLASSES 


/*
  ______      _                 _______ _                                                
 / _____)    | |               (_______) |                        _                      
| /      ____| | ____  ___  ___ _____  | | ____ ____   ____ ____ | |_                    
| |     / ___) |/ _  |/___)/___)  ___) | |/ _  )    \ / _  )  _ \|  _)                   
| \____( (___| ( ( | |___ |___ | |_____| ( (/ /| | | ( (/ /| | | | |__                   
 \______)____)_|\_||_(___/(___/|_______)_|\____)_|_|_|\____)_| |_|\___)                  
=========================================================================================                                                                        
*/

// This is a property or method of a class
//----------------------------------------
class CclassElement{
  constructor(LineNo,Type,Name,Args,Comments,ParentClass){
    if(arguments.length>0){
      if(typeof LineNo == 'object'){
        Object.assign(this,LineNo);  // all primitive types
        //Object.keys(LineNo).forEach(function(K){this[K] = LineNo[K];},this);// replaced by above
      }else{
        this.lineNo = LineNo+1;    // user text starts with line 1
        this.type = Type;
        this.name = Name;
        if(Array.isArray(Args)){
          this.args = Args;
        }else{
          this.args = (Args.trim() === '') ? [] :  Args.split(',');
        }  
        this.comments = Array.isArray(Comments) ? Comments : [];
        this.throwBuffer = [];   // array of [line num, throw string, trailing comments
        this.parentClass = ParentClass;   // obj this belongs to
      }  
    }  
  }
  
  get isPrivate(){
    return (this.name[0]=='_');
  }  
  get rawComments(){
    //console.log('grc',this.comments);
    return this.comments;
  } 
  
  AddThrow(LineNum,ThrowString,Comment){
    this.throwBuffer.push([LineNum,ThrowString,Comment]);
  }  
  
  // the sortname is the ordinary name plus a two character prefix
  // which can be used to sort in display order.  eg constructor at top
  //-------------------------------------------------------------------
  get sortName(){
    var p = this.isPrivate ? 'p' : 'a';
    var t = CclassViewer.SortPrefix(this.type);
    return p+t+this.name;
  }  
  
  
  // line of details report
  //-----------------------
  Tr(Flags,OriginalClass){
    var td1,td2,td3,td4;
    var isInherited = this.parentClass != OriginalClass;
    
    // LINE NUMBER TD 1
    var clName = this.parentClass.name;
    td1 = '<td class="elLineNo"';
    if(isInherited){
      var origSrce = this.parentClass.sourceFile;
      td1 += ' title="'+origSrce+'\nLine:'+this.lineNo+'"><span class="elParentClass tiny">'+clName+'</span></td>\n';
    }else{
      td1 += '>'+this.lineNo+'</td>\n';
    }
    
    // NAME AND TYPE  TD 2    
    var typeCl = CclassViewer.TypeToNameClasses(this.type);
    td2 = '<td class="elName '+ typeCl+'">'+this.name+'</td>';
    
    // ARGS  TD 3
    if(this.type=='THIS'){
      td3 = '<td class="elArgsThis">'+this.args.join('<br>')+'</td>'; 
    }else{  
      td3 = '<td class="elArgs">'+this.args.join('<br>')+'</td>'; 
    } 
    
    // TD-4   COMMENTS
    var skipFormatting = (this.type == 'THIS');
      td4 = '<td class="elComments">'+CclassViewer.FormatComments(this.comments,this.args,skipFormatting).join('\n');
    if(this.type!='THIS'){
      var throwing = '';                   // list of throws
      if(this.throwBuffer.length>0){
        var tlis = this.throwBuffer.map(V=>'<li><span class=throwStr>'+V[1]+'</span>');
        throwing = '<ul class=throws>'+tlis.join('\n')+'</ul>';
      }      
      td4 +='<br>'+throwing;
    }
    td4 += '</td>\n';
    var privCl = (this.isPrivate) ? 'private' : ''; 
    return '<tr class="element '+privCl+'">'+td1+td2+td3+td4+'</tr>\n';
  }
    

  // return a string being the formatted signature
  Signature(ParentObj){
    var n = this.name;
    var args = this.args.join(',');
    var t = CclassViewer.FormatComments(this.comments,[],true).join('\n');
    var rv = '<span title="'+t +'" class="';
    switch(this.type){
    case 'CONSTRUCTOR'   : rv +=  'blue bold">'+ n+'</span>('+args+')'; break;
    case 'GET'           : rv +=  'green">'+n+'</span>'; break;
    case 'SET'           : rv +=  'olive">'+n+'</span>'; break;
    case 'METHOD'        : rv +=  'red">'+n+'</span>('+args+')'; break;
    case 'STATIC-GET'    : rv +=  'm1 lime italic">'+n+'</span>'; break;
    case 'STATIC-METHOD' : rv +=  'italic brown">'+n+'</span>('+args+')'; break;
    case 'THIS'          : rv +=  'green">'+n+'</span>'; break;
    }
    return rv;  
  }
  
  // Return true if TestString is found in the name.
  // Caseinsensitive.
  DoesNameMatch(TestString){
    return this.name.toUpperCase().includes(TestString.toUpperCase);
  }  
  
  
  // Return true if TestString is found in the name.
  // Caseinsensitive.
  DoCommentsContain(TestString){
    return this.comments.join('').toUpperCase().includes(TestString.toUpperCase());
  }  
  
}

class CclassDef_elements extends Cindex{
  constructor(){
    super('name');
  }
}
  


/*                                                                                         
  ______      _                 _____         ___ 
 / _____)    | |               (____ \       / __|
| /      ____| | ____  ___  ___ _   \ \ ____| |__ 
| |     / ___) |/ _  |/___)/___) |   | / _  )  __)
| \____( (___| ( ( | |___ |___ | |__/ ( (/ /| |  
 \______)____)_|\_||_(___/(___/|_____/ \____)_|  
==================================================
*/

  
class CclassDef{
  
  // Extends is a single classname or '';
  // Comments is an array
  constructor(LineNo,Name,Extends,Comments,SourceFile){
    
    if(typeof LineNo == 'object'){
      //console.log('CONSTRUCTING cclassDef FROM OBJECT !!!!!!!!!!');
      
      /*
      Object.entries(LineNo).forEach(function(KV){    
        
        if(KV[0]=='elements'){      // components of a class eg methods, props etc
          this.elements = {};       
          Object.entries(KV[1]).forEach(function(Els){
            this.elements[Els[0]] = new CclassElement(Els[1]);
          },this);
        }else{  
        console.log('xx',KV);
        
          this[KV[0]] = KV[1];   // ordinary values
        }  
      },this); */
    }else{      
      this.lineNo = LineNo+1;    // user text starts with line 1
      this.type = 'CLASS';
      this.name = Name;
      this.comments = Array.isArray(Comments) ? Comments : [];
      this.ext = Extends;           // what does this class extend.  String.
      this.sourceFile = SourceFile;
      this.timeStamp = Date.now();
      this.elements = new CclassDef_elements();            // will be methods etc
      this.lastElementName = '';
      this.dependsOn = [];            // class names in source triggered by new
    }  
  }

  
  // array of class names found in extend and depends
  //---------------------------------------------
  RequiresClasses(){
    var rv = [];
    if(this.ext.length > 0){rv.push(this.ext);}
    this.dependsOn.forEach(function(V){
      if(rv.includes(V)===false){rv.push(V);}
    });
    return rv;
  }
  
  
  //SearchForText(Text)  --> array of elements
  //--------------------------------------------------
  Search(Needle,Exhaustive){
    var results = [this.name];
    var un = Needle.toUpperCase();
    // classname
    var found = this.name.toUpperCase().includes(un);
    if(found){
      results.push(['class',this.name]);
      if(!Exhaustive){return results;}
    }
    // comments
    found = this.comments.join('\n').toUpperCase().includes(un);
    if(found){
      results.push(['class comments',this.comments]);
      if(!Exhaustive){return results;}
    }
    // method names
    var els = this.elements.ListKeys(this.elements.Filter('DoesNameMatch',un));
    found=(els.length>0);    
    if(found){
      els.forEach(function(V){
        results.push(['method name',V.ElmtName()]);
      });  
      if(!Exhaustive){return results;}
    }
    // method comments
    els = this.elements.ListKeys(this.elements.Filter('DoCommentsContain',un));
    
    found=(els.length>0);    
    if(found){
      els.forEach(function(V){
        results.push(['method comments',V.rawComments]);
      });  
    }
    return results;
  }
  
  Element(Name){
    return this.elements.Get(Name);
  }  
  
  // add an element
  AddElement(LineNo,Type,Name,Args,Comments){
    this.lastElementName = (Type=='CONSTRUCTOR') ? this.name : Name;
    this.elements.Add(new CclassElement(LineNo,Type,this.lastElementName,Args,Comments,this));
  }

  // add a throw to the most recent element
  AddThrow(LineNum,ThrowString,Comment){
    this.Element(this.lastElementName).AddThrow(LineNum,ThrowString,Comment);
  }
  
  // element names in display order.  Constructor > Static > Meths and Props > 'private'
  get elementNames(){
    var ns = this.elements.Singlets('sortName');
    ns.sort();  
    return ns.map(N=>N.substr(2));
  }  

  // Array of element item names 
  // Each string is p|a + type sort str + method name + | + className.
  // we use this to get a mergeable list when dealing with extends
  get sortableNames(){
    return this.elements.Singlets('sortName');
  }
  
  
  
  // Return array of unsorted [element] including any inherited but
  //  eliminating inherited methods which have been overridden.
  //---------------------------------------------------------------
  AllElements(Flags){
    // here are this class's native elements
    var rv = this.elements.Filter();
    var sns = this.sortableNames;
    
    if((Flags.hasOwnProperty('inherited')===false)||(Flags.inherited===true)){
      
      // get inherited elements, if any
      var inElmts = [];
      if(this.ext != ''){
        var ex = cix.Get(this.ext);
        if(ex){
          inElmts = ex.AllElements(Flags);
        }else{
          // Unable to reference super-class.  Could be legit.
        }        
      }
      // weed the inherited/overwritten 
      inElmts = inElmts.filter(function(E){
        if(E.type == 'CONSTRUCTOR'){return false;}
        if(sns.includes(E.sortName)){return false;}
        return true;
      });
      rv = rv.concat(inElmts);
    }
    
    // combine this and inherited  
    return rv;
    
  }  
  
  
  // find non-overidden inherited elements
  // eliminate private methods and return html  
  //---------------------------------------------------------------
  GetSignatures(Flags){    
    var els = this.AllElements(Flags);   // [elmt]
    els.sortOnData('sortName');
    return els.filter(E=>(E.isPrivate===false)).map(E=>E.Signature(this));
  }  
  
  // find non-overidden inherited elements
  // ratain private methods and return html for details
  // Flags control details of display
  //---------------------------------------------------------------
  GetDetails(Flags){
    var els = this.AllElements(Flags);   // [elmt]
    els.sortOnData('sortName');
    return els.map(E=>E.Tr(Flags,this));
  }  
  
  
}
  


//  Each entry consists of a CclassDefElement
//===========================================
class CclassIndex extends Cindex{
  
  constructor(){
    super('name');   // name ==> key
  }  
  
  // optional filter is always lowercase
  ClassNames(Filter){
    var cns = this.ListKeys();
    if(typeof Filter=='string'){
      if(Filter.length>2){
        cns = cns.filter(N=>N.toLowerCase().includes(Filter));
      }  
    }  
    return cns; 
  }  
  
  // what does the specified class extend?
  ClExtends(ClName){
    return this.GetField(ClName,'ext');
  }  
  
  // get classes in extends chain and discovered dependencies
  /*ClDependsOn(ClName){
    var rv = false;
    var c = this.Get(ClName);
    if(c){
    BAD BAD   rv = c.ext.concat(c.dependsOn);
    }
    return rv;
  }    
  */
  // 
  
  // get classes in extends chain and discovered dependencies
  //-----------------------------------------------------
  ClRequiresClasses(ClName){
    var rv = [];
    var c = this.Get(ClName);
    if(c){
      rv = c.RequiresClasses();
    }
    return rv;
  }    
  
  // return a unique array of sourcefiles
  // the first element is always that of the class itself
  //-----------------------------------------------------
  ClRequiresSources(ClName){
    var s = [this.ClSource(ClName)];          // source for class
    var rc = this.ClRequiresClasses(ClName);
    rc.forEach(function(V){
      var rs = this.ClSource(V);
      if(s.includes(rs)===false){s.push(rs);}
    },this);  
    return s;
  }
  
  // Return an array of class names this extends
  // nearest at top.  Return empty array if none
  ClExtendsChain(ClName){
    var exts = [];
    var cc = ClName;
    while(true){
      var e = this.ClExtends(cc);
      if((e==='')||(e==undefined)){break;}
      exts.push(e);
      cc = e;
    }
    return exts;
  }
  
  // What is name of source file for specified class
  // return undefined if Clname missing
  ClSource(ClName){
    return this.GetField(ClName,'sourceFile');
  }  
  
  // when was the class last parsed
  // return null string if missing
  ClTimestamp(ClName){
    return this.GetField(ClName,'timeStamp');
  }  
  
  
  // Cheat-sheet style  
  // Scope is 'All inherited' (default) or 'Exclude inherited'
  ClReportSignatures(ClName,Scope){
    var allIn = (typeof Scope=='undefined')||(Scope=='All inherited');
    var html = '<div class="col20 colRule">\n';
    var cl = this.Get(ClName);
    if(cl===false){return '<div class="bgred">Class '+ClName + ' not in index</div>';}
    var topBlurb = ' title="'+cl.comments.join('\n')+'" '; 
    
    var echain = this.ClExtendsChain(ClName);
    echain = echain.map(function(N){
      var rv =  '<span class="f150 bold">&laquo;</span> ';
      var ecl = this.Get(N);
      if(ecl){
        return rv+'<span class="brown bold">'+N+'</span>';
      }else{
        return rv+'<span class="violet">'+N+'(<span class="italic black">missing</span>)</span>';
      }
    },this).join('');
    
    //var echain = this.ClExtendsChain(ClName).map(V=>' &laquo;<span class=orange>'+V+'</span>').join('');
    html += '<div class="pad round1 bgwhi">\n<span class="bold f120 frame1 round1 pad"'+
    topBlurb+'>'+ClName+'</span>'+echain+'<p>\n';

    var sigs = cl.GetSignatures({inherited:allIn});   
    html += sigs.join('<br>') + '</div></div>';
    return html;
  }  
    

  // verbose style    
  // Scope is 'All inherited' (default) or 'Exclude inherited'
  ClReportClass(ClName,Scope){
    var allIn = (typeof Scope=='undefined')||(Scope=='All inherited');
    
    var srcComments = '';
    this.missingClasses = [];  // working var
    var cl = this.Get(ClName);
    if(cl===false){return '<div class="bgred">Class '+ClName + ' not in index</div>';}
    
    // source link and comments
    var srcName =  cl.sourceFile ;
    var src = six.Get(srcName);
    if(src instanceof Csource){ // bloody well should be!
      var srcLnk = '<span class="button f10" onclick="ExpandSourceComments(this);">'+srcName+'</span>';
      srcComments = '<div>'+srcLnk+'<div class="topComments hidden frame1">'+src.Report(this)+'</div></div>';
    }  
    
    
    // class title and extensions
    var echain = this.ClExtendsChain(ClName);
    var ec = echain.map(function(V,I){return'<span class="extends'+I+'">'+V+'</span>';});
    var eh = (ec.length>0) ? ' &Lt;'+ec.join('&Lt;') : ''; 
    // sources for echain
    var sc = echain.map(function(V){return this.ClSource(V);},this);
    
    var t = 'title="'+src+'"';
    var nameAndExtends = '<div class=className><span '+t+'>'+cl.name+'</span>'+eh+'</div>';
    //console.log('cln',cl.name,cl.formattedComments.join('\n'));
    
    var com = '<div class=classComments>'+CclassViewer.FormatComments(cl.comments,[]).join('<br>')+'</div>';  
    
    var trs = cl.GetDetails({inherited:allIn});
         
    var tbl = '<table class="boxed">' + trs.join('\n') + '</table>';
    this.missingClasses = [];  // tidy up
    return '<div class=classReport>'+srcComments+nameAndExtends+com+tbl+'</div>';  
   
  }

  // run .Search() on all sources
  // returns any where something is found
  Search(Needle,Exhaustive){
    var m= this._records.map(function(V){
      return V.Search(Needle,Exhaustive);
    });
    return m.filter(V=>V.length>1);
  }    

  
}  
  
CJC.RegisterConstructors([CclassIndex,CclassDef,CclassDef_elements,CclassElement]);  
 