//=========================================================
//  TREE DISPLAY class 
//=========================================================



class Ctree{
  
  // ContainerId is DOM reference
  // Settings is optional object
  //    pinOnClick:   boolean to show an item has been clicked
  //    onClickDo:    function(lineText,rowIndex,isAdirectoryBoolean)
  //-----------------------------------------------------------------
  constructor(ContainerId,Settings){
    this.containerId = ContainerId;
    this.path = false;
    this.extensions = false;
    this.tree = [];    // each row is [name,lines display string, directory flag, parent row ix, user status flags] 
    this.fr = new CfileReader(this);
    this._InstallCSS();
    this.loaded = false;    // only true after a proper file discovery and tree creation
    this.lastClickedIx = -1;
    
    this.settings = (typeof Settings == 'object') ? Settings : {pinOnClick:true};   // we may want to tweak behaviour
  }

  SetFileSpec(Path,Extensions){
    this.path = Path;
    this.extensions = Extensions;
  }

  
  Clear(){
    this.tree = [];    
    this.loaded = false;    // only true after a proper file discovery and tree creation
    this.lastClickedIx = -1;
  }
  
  // Given a list of files we will convert it to a tree
  // Note: This is a static method so it's available outside as a utility called with Ctree.ConvertToTree()
  //---------------------------------------------------
  static ConvertToTree(FileArray){
    FileArray.sort();
    //console.log('FA',FileArray.join('\n'));
    
    var fa = FileArray.map(function(V){return V.split('/');});    // array of arrays  
    var tree = [];
    var stem,rest;
    fa.unshift([]);
    fa.forEach(function(R,I,A){
      if(I>0){
        stem=[];
        rest=R.slice();
        var p = fa[I-1];
      
        while(rest.length>0){
          if(rest[0]==p[stem.length]){
            stem.push(rest.shift());
          }else{
            break;
          }
        }   // stem contains bits that are same as previous.  row is remaining bits
        
        while(rest.length>0){
          stem.push(rest.shift());
          tree.push(stem.slice());
        }  
      }
    });   // never more than single sub in one line  
      
    // Find out where the duplicate elements are
    var higherRow;  
    tree.reverse();   // change to bottom first
    tree.forEach(function(R,I){
      if(I<tree.length-1){    // ignore 'top' row
        higherRow=tree[I+1];
        for(var c=0;(c<R.length)&&(c<higherRow.length);c++){
          if(R[c]==higherRow[c]){tree[I][c]='dit';}
        }
      }
      //console.log(I,tree[I].join('|'));
    });

    // we've now got all the duplicates marked
    // Next job is to convert that pattern of dittos to 
    //    blank    ...  not ditto 'below' and ditto to right
    //    L        ...  not ditto 'below' and not ditto to right
    //    +        ...  ditto 'below' and not ditto to right
    //    |        ...  ditto 'below' and ditto to right
    // The tree is still upside down so we'll be starting from the bottom
    var belowIsDitto,rightIsDitto,belowIsLine;
    var previousRowLength = 0;
    tree.forEach(function(Row,Rix){
      Row.forEach(function(Cell,Cix){
        if(Cell == 'dit'){        // is this a ditto to be modified?
          belowIsDitto = (Cix>previousRowLength-1) ? false : (tree[Rix-1][Cix]=='dit');    // what's 'below'
          rightIsDitto = (Cix>Row.length) ? false : (Row[Cix+1]=='dit');    // first option is an error!  Can never happen.
          belowIsLine  = (Cix>previousRowLength-1) ? false : '+|L'.includes(tree[Rix-1][Cix]);    // what's 'below'
          if(belowIsDitto||belowIsLine){
            tree[Rix][Cix] = rightIsDitto ? '|' : '+';
          }else{
            tree[Rix][Cix] = rightIsDitto ? ' ' : 'L';
          }
        }  
      });      
      previousRowLength = Row.length;
    });  

    tree.reverse();  
    return tree;
  }    

  // we may have a set of files aready
  // so long as we have the path names as well then we're
  // good to shove them into the tree
  InsertFiles(FullFileNamesArray){
    this.path = '';
    this.loaded = true;
    this.deferredShow = true;
    this._ContinueReadFiles(FullFileNamesArray);
  }  
  
  // Find the files in the dirs specified 
  // Setting DeferredShow true if immediately show after read is probably a good idea
  ReadFiles(DeferredShow){
    this.loaded = false;
    this.deferredShow = DeferredShow || false;
    this.fr.DiscoverFiles(this.path,this.extensions,false,this._ContinueReadFiles);
  }
  
  // continuation using list of discovered files
  _ContinueReadFiles(FileArray){
    FileArray.sort();
    
    var fa = FileArray.map(function(V){return V.replace(this.path,'');},this);
    
    var workingTree = Ctree.ConvertToTree(fa);   //FileArray
    var treeLength = workingTree.length;
    this.tree = workingTree.map(function(V,I){
      var r = V.slice();
      var n = r.pop();
      var d = n.includes('.');
      return [n,r.join(''),d,-1,{}];
    });       
    // find the parent of each row
    this.tree.forEach(function(V,I){this.tree[I][3]=this._ParentRow(I);},this);
    
    this.loaded = true;
    if(this.deferredShow){this.Show(true);}
  }

  
  // Roots is an array of paths which are roots to trees to explore
  // NameMatchRex is a RegEx to select on filenames
  // ThenDo is a method to execute when all files are loaded
  //----------------------------------------------------------------  
  LoadFromRoots(Roots,NameMatchRex,ThenDo,Append){
    if(!Append){
      this.Clear();}
    var tree = this;
    var rs = Roots.map(function(V){
      if(typeof V == 'string'){
        return [V,NameMatchRex];
      }else{
        return V;
      }
    });      
    aq = new CasyncQueue(this,rs,
            function(Root){
            fr.DiscoverFiles(Root[0],Root[1],false,
                function(Flist){
                  if(aq.Continue(Flist)){return;}   // do next root
                  // after all the roots processed...
                  //var clFiles = aq.Results().filter(V=>V.match(NameMatchRex));  // filter files
                  var clFiles = aq.Results();
                  tree.InsertFiles(clFiles);
                  if(typeof ThenDo=='function'){ThenDo();}
                }
            );},
            []);
  }
  
  /*aq = new CasyncQueue(this,Roots,
    
    this._DiscoverMoreFiles,[]);
  } //  >>>----v    Child of .LoadFromRoots
    _DiscoverMoreFiles(Root){
      fr.DiscoverFiles(Root,'js',false,function(Flist){
        if(aq.Continue(Flist)){return;}   // do next root
        // after all the roots processed
        var clFiles = aq.Results().filter(V=>V.match(NameMatchRex));  // filter files
        this.InsertFiles(clFiles);
        if(typeof ThenDo=='function'){ThenDo();}
      });
    }
  */
  
  // display the tree in whatever container we gave 
  // in the constructor  
  Show(Shrink){
    var h = this.Html();
    $('#'+this.containerId).html(h).on('click','li',this,this._ClickHandler);
    //if(Shrink){this.ShrinkToFit();}
  }
  
  _ClickHandler(Event){
    var tree = Event.data;                                // ourselves 
    var tar = $(Event.target);                            // actual target.  
    var li  = tar.is('li') ? tar : tar.parents('li');     // may be li or descendent
    var liId = li.attr('id').split('_');                  // <container id>_<index>
    var rowIx = parseInt(liId[1],10);                     // shouldn't be necessary.  (Old habits)
    var fname = tree._FullNameForRow(rowIx);
    
    if(tree.settings.pinOnClick){                         // possibly add a pin 
      tree.RemovePin();
      tree.AddPin(rowIx);
    }
    tree.lastClickedIx = rowIx;    
    if(typeof tree.settings.onClickDo == 'function'){
      tree.settings.onClickDo.call(tree.onClickContext,fname,rowIx,tree._IsDir(rowIx));
    }  
  }  
    
  // remove the last pin  
  RemovePin(){
    if(this.lastClickedIx>-1){
      var namespan = $('#'+this._LiId(this.lastClickedIx)+' span').filter(':last');
      namespan.removeClass('pin');
    }  
  }

  // add the pin flag to this row
  AddPin(RowIxOrFileName){
    var rix = $.isNumeric(RowIxOrFileName) ? RowIxOrFileName : this.LookUpFileName(RowIxOrFileName);
    var namespan = $('#'+this._LiId(rix)+' span').filter(':last');
    namespan.addClass('pin');
  }  
  
  // return index or -1
  LookUpFileName(FullName){
    return this.tree.findIndex(function(V,I){
      return (FullName == this._FullNameForRow(I));
    },this);
  }  
  
  // what is id for this row
  _LiId(RowIx){
    return this.containerId+'_'+RowIx;
  }  
  
  // html for whole tree 
  Html(){
    var lis = this.tree.map(function(V,I){
      return this._RowHtml(I);
    },this);
    return '<ul class="flistTree">' + lis.join('\n') + '</ul>';
  }  
  
  
  // html for specified row
  _RowHtml(RowIx){
    var title = this._FullNameForRow(RowIx);  //@@@ might want this to be a fancy function
                                              //@@@ might want to append to tree rows anyway   
    var li = '<li id="'+this._LiId(RowIx)+'" title="'+title+'">';
    var lines = this._LinesForRow(RowIx);
    var name = this._HtmlNameForRow(RowIx);    
    return li+lines+name;
  }  

  // name might be embellished with css classes etc
  _HtmlNameForRow(RowIx){
    var cl = (this._IsFile(RowIx)) ? 'flistFile' : 'flistDir';
    var n = this._NameOnRow(RowIx);
    return '<span class="'+cl+'">'+n+'</span>';
  }    
  
  
  // html spans which describe the joining lines
  _LinesForRow(RowIx){
    var lineBits = this.tree[RowIx][1].split('');   // string of | + L and blank -> chars
    var spans = lineBits.map(function(V){
      var i = ' L|+'.indexOf(V);
      if(i<0){
        return '<span>_LinesForRow Err</span>';  // can never happen
      }else{
        return '<span class="flistLine flistLine'+'BLIT'.substr(i,1) + '"> </span>';
      }  
    });  
    return spans.join('');
  }    
  
  // what's the length of the path part for this row
  _PathLength(RowIx){
    return this.tree[RowIx][1].length;
  }  
  
  // find the higher directory for this row
  _ParentRow(RowIx){
    var rv = -1;
    var plToFind = this._PathLength(RowIx)-1;
    for(var r=RowIx-1;r>0;r--){
      if((this._PathLength(r)==plToFind)&&(this._IsDir(r))){
        rv = r;
        break;
      }
    }
    return rv;
  }
  
  // return array of children FILES
  // if RowIx is 0 then get all
  //-------------------------------
  ChildFiles(RowIx){
    var pthLen = this._PathLength(RowIx);
    var pl;
    var rix = RowIx+1;
    var children = [];
    while((rix<this.tree.length)&&(this._PathLength(rix)>pthLen)){
      pl = this._PathLength(rix);
      if(this._IsFile(rix)){
        children.push(this._FullNameForRow(rix));
      }
      rix++;
    }
    return children;    
  }  
  
  
  // return array of children NAMES
  // if RowIx is 0 then get all
  //-------------------------------
  ChildNames(RowIx){
    var pthLen = this._PathLength(RowIx);
    var pl;
    var rix = RowIx+1;
    var children = [];
    while((rix<this.tree.length)&&(this._PathLength(rix)>pthLen)){
      pl = this._PathLength(rix);
      if(this._IsFile(rix)){
        children.push(this._NameOnRow(rix));
      }
      rix++;
    }
    return children;    
  }  
  
  
  
  
  Match(MatchFun){
    var fa = [];
    this.tree.forEach(function(V,I){
      if(this._IsFile(I)){
        if(MatchFun(V,I)){
          fa.push(this._FullNameForRow(I));
        }
      }
    },this);
    return fa;
  }
  
  
  // get name which is first item on row
  _NameOnRow(RowIx){
    return this.tree[RowIx][0];
  }  
  
  // is this row a file
  _IsFile(RowIx){
    var n = this._NameOnRow(RowIx);
    return n.includes('.');
  }

  // is this row a dir
  _IsDir(RowIx){
    return (this._IsFile(RowIx)===false);
  }

  // reconstruct the full name of the file/dir by working up to the previous
  // levels in the path   
  _FullNameForRow(RowIx){   
    var pRow;
    var pth = [this._NameOnRow(RowIx)];
    var r = RowIx;
    while((pRow = this.tree[r][3])>=0){
      pth.unshift(this._NameOnRow(pRow));
      r = pRow;
    }
    return this.path+'/'+pth.join('/');    
  }  
  
 

  
  // Convert list of files into an alphabetical list
  FlattenAlphabetically(DomElementId,OnClick){
    var anames = [];
    this.tree.forEach(function(R,I){
      if(this._IsFile(I)){
        anames.push([R[0],I,this._FullNameForRow(I)]);  // name,Ix,Title
      }
    },this);
    anames.sortOnData(0);
    var spans = anames.map(function(NIT){
      return '<span class="tree_alpha_name" title="'+NIT[2]+'">'+NIT[0]+'</span><br>';
    });  
    
    $('#'+DomElementId).html(spans.join('\n'));
  }
  
  GetAllFiles(){
    var rv = [];
    this.tree.forEach(function(R,I){
      if(this._IsFile(I)){
        rv.push([R[0],this._FullNameForRow(I)]);  // name,Title
      }
    },this);
    rv.sortOnData(0);
    return rv;
  }  
  
  
  // Sets up the necessary css  
  _InstallCSS(){
    var cssId = 'CtreeCSS';                  // give this css an id so we don't reload it
    if($('#CtreeCSS').length===0){           // more than once
    
    // inline graphics for css
    // ~~~~~~~~~~~~~~~~~~~~~~~
var lB = 'ul.flistTree span.flistLineB {background-image:url("data:image/gif;base64,R0lGODlhCgAQAPcAAP///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////yH5BAEAAAAALAAAAAAKABAAAAgXAAEIHEiwoMGDCBMqXMiwocOHECMeDAgAOw==")}';

var lI = 'ul.flistTree span.flistLineI {background-image:url("data:image/gif;base64,R0lGODlhCgAQAPcAAEJCQr29vc7Ozv///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////yH5BAEAAAMALAAAAAAKABAAAAgxAAcIFAAggMCDAwsiPEjQ4MIBDR9CVPgwYkWKCy1mxIhQY0eODEEmdLiR5EeTIU0GBAA7")}';

var lL = 'ul.flistTree span.flistLineL {background-image:url("data:image/gif;base64,R0lGODlhCgAQAPcAAEJCQlpaWmtra729vc7OztbW1v///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////yH5BAEAAAYALAAAAAAKABAAAAgxAA0IJABggMCDAwsiPEjQ4EIDDR9CVPgwYkWKCwkGEMBRwMECAUKKlEiypMmTKFMGBAA7")}';

var lT = 'ul.flistTree span.flistLineT {background-image:url("data:image/gif;base64,R0lGODlhCgAQAPcAAEJCQlJSUlpaWmtra729vc7Ozv///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////yH5BAEAAAYALAAAAAAKABAAAAg6AA0ILACAgMCDAwsiPEjQ4EIDDR9CVPgwYkWKCwkKGMBxAEMAAQSIFPDRYUaMCC2eNJkSZUmJKg0EBAA7")}';

var pin = '.pin {background-repeat:no-repeat;padding-left:16px;background-position:0 0;  background-image:url("data:image/gif;base64,R0lGODlhDAAXAPcAACEICCEhITEICDEpKTExMTkICDkpKTkxMTk5OUJCQkoQEEoYGEopKUpKSlIQEFJKSlJSUloQEFpCQlpaWmMQEGNKQmNaWmNjY2tra3MQEHMYGHsYGHtKOXtSOXt7e4QYGISEhIwYGIyEhIyMjJSUlJwhIaUhIaWlpa0hIa2trbUhIbW1tb0pKb29vcbGxs4pKc5KQs7OztbW1ucpKedjUufn5+8xMe/v7/cxMff39/8xMf85Of9COf9SQv///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////yH5BAEAAD4ALAAAAAAMABcAAAixAH0IFFjjxsCDAiV06FDBgwyELQTY4NGDBgcLBgWeoODAhA0dPGA8OGiAwoYIEUJ8ODCwhoYXGhxs2FBgxEAQL3TowKHCQIuBKxjs0KkDBYmBIjSEIKrDQUYfE1hQ+KhjBsuBMRaUUPABRQQHP4ECCFEihIkIMQ6eAEEiQAMMYQdeSJEiAcKBCVpMSHHXh4y9dvuSGLG3L9QTge/mSFC4r4sJie+CSMDXMITIdwnE7RsQADs=")}';    
    
    
      var css = '<style id='+cssId+'>'+      // here's the css 
        'ul.flistTree                 {display:table;list-style-type:none;margin-left:0px;padding:3px;}'+
        'ul.flistTree>li              {max-height:16px; padding:0; margin:0;}'+
        'ul.flistTree>li:hover        {background-color:#ddd;}'+
        'ul.flistTree span.flistFile  {color:green;}'+
        'ul.flistTree span.flistDir   {color:blue;}'+
        'ul.flistTree span.flistLine  {display:inline-block;min-width:10px;height:16px;}'+
        //'ul.flistTree span.flistLineL {background-image:url("./LineL.gif");}'+ 
        //'ul.flistTree span.flistLineB {background-image:url("./LineB.gif");}'+ 
        //'ul.flistTree span.flistLineT {background-image:url("./LineT.gif");}'+ 
        //'ul.flistTree span.flistLineI {background-image:url("./LineI.gif");}'+ 
        lB+lI+lL+lT+pin +      
        '</style>';
      $('head').append(css);                 // whack it into the head
    }      
  }

  
  
  
  
}
  