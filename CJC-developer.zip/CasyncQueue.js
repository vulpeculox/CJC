// Class which executes an asynchronous function
//  with a sequence list of arguments in turn.
//
// USAGE PATTERN
// | var aq = new CasyncQueue(this,someArray,AsyFun);
//  This starts off the whole thing
// 
// function AsyFun(Arg){
//   ... async start ...
//   ... with promise to call HandleAsyFunResult
//
// function HandleAsyFunResult(){
//   ... do whatever with result of async func
//   if(aq.Continue()){return;}   // triggers next item in queue     
//   ... do whatever after all finished 
// 
//
// EXTRA FEATURE
// A common pattern is collecting an array of results.  To save using a wandering var
//  you can give the resulting !array! of the async function to the queue for storage.
//  Now your result handler looks like:
//    ... do whatever with result of async func
//    ... here recentResults will be added to aq's internal results array
//   if(aq.Continue(recentResults)){return;}   // triggers next item in queue     
//    var allMyResults = aq.Results();         // fetch the concatenated results
//    ... do whatever after all finished 
//    ...     
//===========================================================================
class CasyncQueue{

  // Setup and start
  // Context, typically this, is context for the LoopFunction
  // ToDo is either an array of anything or a string with elements split by commas
  // LoopFunction(EachArgInTurn) is what's called each time.
  //  Remember this function will lead to a result handler which must
  //  have the !if(someQueue.Continue()){return;}! to repeat
  //  or fall through if no more to a finished all situation
  // Note that once constructed, this queue must be visible to the
  //  result handler.
  //---------------------------------------------------------------------  
  constructor(Context,ToDo,LoopFunction){
    this.loopContext = Context;
    this.todo  = (typeof ToDo=='string') ? ToDo.split(',') : ToDo.slice();
    this.loopFunction = LoopFunction;
    if(typeof this.loopFunction != 'function'){throw "CasyncQueue needs a function!";}
    this.resultsArray = [];
    
    this.Continue();
  }

  // repeat with next element in queue
  // return false if no more to do
  // RecentResult is an optional array which can be added to an internal
  // array of results  
  //---------------------------------------------------------------------  
  Continue(RecentResults){
    if(Array.isArray(RecentResults)){
      this.resultsArray = this.resultsArray.concat(RecentResults);
    }
    if(this.todo.length<1){return false;}   
    var next = this.todo.shift();
    this.loopFunction.call(this.loopContext,next);
    return true;
  }

  // Get concatenated results  
  //---------------------------------------------------------------------  
  Results(){
    return this.resultsArray;
  }
  
  
}
