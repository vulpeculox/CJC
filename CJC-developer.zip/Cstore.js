// Template for some object storage
//
// The main methods are PUT and GET which are pretty obvious.  They
//  take a Keys argument which may be a string split by '/' as with 
//  a typical file path, or an array of 'path' elements.  The last element
//  of the keys is equivilent to the filename.
//
// This is a virtual class/interface which needs to be implemented
//  by a sub-class connected to a specific storage mechanism.
//
// The SubKeys() method is a way of keeping track of 'sub-directories'

//. Requires class CJC  sourced in CimpExp.js

// An abstract class to be an interface and helper to real storage classes
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// *Data* is typically an object.  You almost certainly want to make CJC aware
//  of it with CJC.RegisterConstructors()
// *Keys* is actually any string you like, but it's !conventional! here to use
//  the !path/name/filename! pattern 'cos that way we can
//    (a) map to a real file system if we want, and 
//    (b) navigate and manipulate in familiar ways.
// Note: Keys can be specified in the form "/foo/bar/buz/" or ['foo','bar','buz']
// Note: Normally the last element of a *Keys* is the 'filename' (object label).
//  You can have an object with the full label "/foo/myObj" AND ALSO an object with
//  a label "/foo/myObj/someSubObj"
// Note: You could be silly with characters used in keys but why not be sensible
//  and stick to a-z,A-Z,0-9 and _?
// *.keyRoot* is something to set in the constructor.  You can't reach higher
//  than this.  
// You could use .Export() and .Import() to backup or synchronise two stores.
//  For example one might be on a server and the other local.
class Cstore{
 
  //. You really need to set the .keyRoot as that limits the realm you can trash!
  //------------------------------------------------------------------------------
  constructor(){
    this.changed = false;
    this.keyRoot = '';
  }
  
/*  //----------------------------------------------------------
  Put(Keys,Data){throw 'abstract method!';}

  //. ThenDo is an optional function
  //----------------------------------------------------------
  Get(Keys,ThenDo){throw 'abstract method!';}

  //. AndChildren deletes all sub-keys as well
  //----------------------------------------------------------
  Delete(Keys,AndChildren){throw 'abstract method!';}

  //. ThenDo is ann optional function
  // Note:  For consistency this will return the given key itself as well
  //  as any subs
  //----------------------------------------------------------
  SubKeys(Keys,ThenDo){throw 'abstract method!';}
  
  // Really will be a string such as "YES"
  // Note: This will wipe *EVERYTHING* down to .keyRoot!  Obviously
  //  this is a rather unusual activity   There's no undelete!
  //----------------------------------------------------------
  WipeAreYouReallySure(Really){throw 'abstract method!';}


  // Return a complete list of keys and values(as doublet strings)  
  // See .Import()
  //----------------------------------------------------------
  Export(){throw 'abstract method!';}
  
  // Bulkload from an array of [key,value] strings
  // If Wipefirst is true then zap first
  // See .Export()
  //----------------------------------------------------------
  Import(KeysAndValues,WipeFirst){throw 'abstract method!';}
  
*/
  
  // Keys can be an array or already a string split by /.../
  // Return *complete* 'path' including the root as a string
  // Weed out any loopy characters
  //---------------------------------------------------------
  _JoinKeys(Keys){
    if(typeof Keys == 'undefined'){throw "Cstore._JoinKeys() needs an argument";}
    var k = Array.isArray(Keys) ? Keys.join('/') : Keys.toString();
    if(!k.startsWith(this.keyRoot)){k = this.keyRoot + '/'+ k;}
    k = k.replace('//','/');                // safety to avoid double slashes
    k = k.replace(/[^a-zA-Z0-9.\/_]/g,'_');   // safety to avoid silly characters
    return k;
  }

  // strip the root path from the start of the path to leave the key part
  //---------------------------------------------------------------------
  _UnjoinPath(Path){
    var rpsl = this.keyRoot+'/';
    var rv = Path;
    if(rv.startsWith(rpsl)){ rv = rv.substr(rpsl.length); }
    return rv;
  }
  
  // Convert a jsonish string into an object using CJC
  //---------------------------------------------------------
  _JstrToObj(JsonStr){
    var rv = {};
    if(typeof JsonStr == 'string'){rv = CJC.FromJ(JsonStr);}
    return rv;
  }
  
    
  // Convert an object into a jsonish string
  //---------------------------------------------------------
  _ObjToJstr(SomeObj){
    return CJC.ToJ(SomeObj);
  }
  

  // Load an object from store or create it.
  // Example: 
  // | myIndex=myStore.GetOrCreate('IXREF',Cindex,'name');  
  // Key is string or array relative to the .keyRoot
  // Constructor is a class (or any constructor CJC knows about)
  // Up to four optional arguments can be supplied to the constructor *if*
  //  the object has to be created from scratch.
  //
  // Note: 
  // This is a !really clever method! to use on some classes as if they have 
  //  .store and or .storeKey properties (which you have to establish in the constructor) 
  //  the values used here will be embedded automatically so that they can save themselves.
  //  All you *have* to do in the class is:
  // (a) put this.store and this.storeKey in the constructor with dummy values
  // (b) use the following code in some Save() method
  // | this.store.Put(this.storeKey,this);  
  //---------------------------------------------------------
  GetOrCreate(Key,Constructor,ConArg1,ConArg2,ConArg3,ConArg4){
    var o = this.Get(Key);
    if((o instanceof Constructor)===false){
      //console.log('GoC Create:',Key,Constructor.name,CJC.IsConstructorRegistered(Constructor.name));
      
      switch(arguments.length){
      case 2 : o = new  Constructor();break;
      case 3 : o = new  Constructor(ConArg1);break;
      case 4 : o = new  Constructor(ConArg1,ConArg2);break;
      case 5 : o = new  Constructor(ConArg1,ConArg2,ConArg3);break;
      case 6 : o = new  Constructor(ConArg1,ConArg2,ConArg3,ConArg4);break;
      }
    }
    if('store' in o){o.store = this;}
    if('storeKey' in o){o.storeKey = Key;}
    return o;
  }

  //@@@ autosave goes here @@@
}
  

  
  
  

//===========================================================================
// Implement a store for objects in localStorage
// A feature is that we need to keep track of the 'directory structure'
//  ourselves as localStorage doesn't have a way to list 'sub-dirs'
// This is done in a 'private' array stored as <ROOT>/_path_tree_
//===========================================================================
class ClocalStore extends Cstore {
  
  // RootPath is a string which differentiates this part of 
  //  localStorage from any other.  Typically related to
  //  the application name.
  //---------------------------------------------------------------------------  
  constructor(RootPath){
    super();
    this.keyRoot = RootPath;
  }
  
  // Convert array of path-elements or a slashed-string into the 
  //  full path format we use for keying 
  //---------------------------------------------------------------------------  
  _JoinKeys(Keys){
    var rv = super._JoinKeys(Keys);
    return rv.replace('//','/');  // safety check
  }

  // Write Data under the specified keys
  // Data can be a proper fully fledged object  
  // Keys is slashed-string or array
  //---------------------------------------------------------------------------  
  Put(Keys,Data){
    localStorage.setItem(this._JoinKeys(Keys),CJC.ToJ(Data));
    this.changed = false;
  }

  // Return *an object* (if an object was stored) or undefined
  // Keys is slashed-string or array
  //---------------------------------------------------------------------------  
  Get(Keys){
    var cjson = localStorage.getItem(this._JoinKeys(Keys));
    if(cjson != undefined){
      return this._JstrToObj(localStorage.getItem(this._JoinKeys(Keys)));
    }
    return undefined;    
  }

  // Return a sorted array of keys *including the given key* and all sub-keys
  // If Trim is true then only return the sub-parts of the 'path'
  // Keys is slashed-string or array
  //@@@@@@@@@ also add an exists method below and in Cstore
  //---------------------------------------------------------------------------  
  Keys(Keys,Trim){
    var rv = [];
    var klen = localStorage.length;
    var pth=super._JoinKeys(Keys);
    for(var kix=0;kix<klen;kix++){
      var k = localStorage.key(kix);
      if(k.startsWith(pth)){
        rv.push(k);
      }  
    }
    if(Trim){
      var pl = pth.length;
      rv = rv.map(V=>V.substr(pl));
    }  
    rv.sort();
    return rv;
  }  
  
  Exists(Keys){
    var kys = this.Keys(Keys);
    var pth=super._JoinKeys(Keys);
    return(kys.includes(pth));
  }  
  
  // delete this key-path
  // Keys is slashed-string or array
  // If AndChildren is true then delete sub-children as well
  // Note.  If AndChildren is not true then *they will remain*
  //---------------------------------------------------------------------------  
  Delete(Keys,AndChildren){
    var sk = [];
    var k = super._JoinKeys(Keys);
    if(AndChildren){sk = this.Keys(k);}
    sk.push(k);
    sk.forEach(function(V){
      localStorage.removeItem(V);          // remove from actual store
    });
  }

  // *DANGER!*  Shortcut for .Delete('',true) which wipes all data under the root
  //---------------------------------------------------------------------------  
  WipeAreYouReallySure(Really){
    if(Really=='YES'){
      this.Delete('',true);
    }
  }    
    
  // Return a complete list of keys and values(as doublet strings)  
  Export(){
    return this.Keys('').map(function(K){
      return [K,localStorage.getItem(K)];
    });
  }
  
  // Bulkload from an array of [key,value] strings
  // If Wipefirst is true then zap first
  Import(KeysAndValues,WipeFirst){
    if(WipeFirst===true){this.WipeAreYouReallySure('YES');}
    KeysAndValues.forEach(function(KV){
      localStorage.setItem(K,V);
    });
  }    
    
    
}
