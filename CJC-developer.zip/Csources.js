// INDEX OF SOURCES
// Derrived from Cindex

// storage element for source details
//===========================================
class Csource {
  
  constructor(FileName,TopBlurb,ClassNames,ParseTimestamp){
    if(arguments.length>0){
      this.fileName = FileName;
      this.topBlurb = TopBlurb;  // array of strings
      this.classNames = ClassNames;
      this.parseTimestamp = ParseTimestamp;
    }  
    this.needsClasses = [];
    this.needsSources = [];
  }

  // Combine all the dependencies of all the classes in the source
  //  creating class and source dependencies
  //--------------------------------------------------------------
  GenAllNeeded(ClassIx){
    this.needsClasses = [];
    this.needsSources = [];

    //console.log('----'+this.fileName+'-----');
    //console.log('CNS',this.classNames.join('|'));

    this.classNames.forEach(function(C){
      var ds = ClassIx.ClRequiresClasses(C);  // array of classes this depends on
      //console.log('DS',ds.join('|'));
      ds.forEach(function(D){
        if(this.needsClasses.includes(D)==false){this.needsClasses.push(D);}
      },this);  
    },this);
    
    //if(this.needsClasses.length > 0){console.log('NC',this.needsClasses.join('|'));}  
    
    this.needsClasses.forEach(function(C){
      var ds = ClassIx.ClRequiresSources(C);
      ds.forEach(function(D){
        if(this.needsSources.includes(D)==false){this.needsSources.push(D);}
      },this);  
    },this);
    var ix = this.needsSources.indexOf(this.fileName);
    if(ix > -1){this.needsSources.splice(ix,1);}
    
  }
  
  // Filter is lowercase string 
  FilterMatch(Filter){
    var rv = true;
    if(typeof Filter=='string'){
      if(Filter.length>2){
        var s = this.sourceName+'|'+this.topBlurb.join('')+'|'+this.classNames.join('');
        rv = s.toLowerCase().includes(Filter);
      }
    }
    return rv;
  }    
  
  // filename without the path
  //--------------------------
  get sourceName(){
    var i = this.fileName.lastIndexOf('/');
    return this.fileName.substring(i+1);
  }     
  
  // HTML for top blurb  
  //-------------------
  TopBlurb(){
    return '<div class=topBlurb>'+this.topBlurb.join('<br>')+'</div>';
  }  
  
  // return array of class objects
  Classes(ClassIndex){
    return this.classNames.sort().map(N => ClassIndex.Get(N));
  }  
    
  
  Report(ClassIndex){
    // class names
    var cns = this.classNames.map(function(V){
      var c = ClassIndex.Get(V);
      var title = (c) ? 'title="'+c.comments.join('\n')+'"' : '';
      var cnClick='onclick="ClassNameClicked(\''+V+'\');" ';
      return '<span class="button" '+cnClick+title+'>'+V+'</span>';
    }).join('<br>');
  
    var dependsRow = '';
    if(this.needsSources.length > 0){
      dependsRow ='<tr><td>Depends on</td><td><div class="bgwhi green">'+this.needsSources.join('<br>')+'</div></td></tr>\n';
    }
    var h = '<div class=sourceReport>'+
            '<div class=sourceTitle>'+this.fileName+'</div>'+
            '<table><tr><td>'+cns+'</td><td>'+this.TopBlurb()+'</td></tr>'+
            dependsRow+'</table>'+
            //'<div class=sourceFooter>'+''+'</div>'+
            '</div>';            
    return h;
  }    

  // look for string (case insensitive)
  // return an array which always has a first item being the filename
  // any subsequent items are doublets [type of thing found,value of thing found]
  // (Value of source comments ie top blurb, is an array of strings
  // If Exhaustive is true then return as soon as something is found in
  //  filename...top blurb...class names  
  //--------------------------------------------------------------------
  Search(Needle,Exhaustive){
    //console.log('searchS',this.fileName);
    
    var results = [this.fileName];
    var what = '';   // will tell where 
    var un = Needle.toUpperCase();
    // filename
    var found = this.fileName.toUpperCase().includes(un);
    if(found){
      results.push(['source file',this.fileName]);
      if(!Exhaustive){return results;}
    }
    // top blurb
    found = this.topBlurb.join('\n').toUpperCase().includes(un);
    if(found){
      results.push(['source comments',this.topBlurb]);
      if(!Exhaustive){return results;}
    }
    // class names
    var cls = this.classNames.filter(function(V){
      return V.toUpperCase().includes(un);
    });
    found=(cls.length>0);    
    if(found){
      cls.forEach(function(V){
        results.push(['class name',V]);
      });  
    }
    if(results.length>1){
      //console.log('r0',results[0]);
    }  
      
    return results;
  }

}
  
//===========================================
class CsourceIndex extends Cindex {
  
  constructor(){
    super('fileName');   // Fileame ==> key
  }  
  
  // run .Search() on all sources
  // returns any where something is found
  Search(Needle,Exhaustive){
    var m = this._records.map(function(V){
      return V.Search(Needle,Exhaustive);
    });
    return m.filter(V=>V.length>1);
  }    

  // Update all needed classes and needed sources for
  //  all sources.
  //-------------------------------------------------  
  GenAllNeeded(ClassIx){
    this._records.forEach(function(S){
      S.GenAllNeeded(ClassIx);
    });
    //console.log('GenAllNeeded done');
    
  }
  
  // List of all sources matching Filter (lowercase)
  //------------------------------------------------
  FilterMatches(Filter){
    var srcs = this._records.slice();
    if(typeof Filter=='string'){
      if(Filter.length>2){
        srcs = srcs.filter(S=>S.FilterMatch(Filter));
      }  
    }  
    return srcs; 
  }  
  
  // HTML Display names for display 
  HTMLAlphaNames(Filter){
    var recs = this.FilterMatches(Filter);
    var flds = recs.map(S=>[S.sourceName,S.fileName,S.topBlurb,S.classNames]);
    flds.sortOnData(0);
    var spans = flds.map(function(A){
      var t = 'Path:'+A[1]+'\nClasses:'+A[3].join(' ')+'\n- - - - - - - - - - - - - - - - - - - - - - - - - - - -\n'+A[2].join('\n');
      return '<span class="tree_alpha_name" title="'+t+'">'+A[0]+'</span><br>';
    });  
    return spans.join('\n');
  }
  
  MatchingNames(Filter){
    var recs = this.FilterMatches(Filter);
    return recs.map(S=>S.fileName);
  }  
  
  
}
  
CJC.RegisterConstructors([CsourceIndex,Csource]);  
 