// Select control
//
// Example usage:
// |  var selMode = new Cselector('buttons','mode','Mode','None,Tall,Wide','Display mode',ModeChanged);
// Change value programatically with selMode.SetOption('Tall') etc.
// When the onchanged function is called it is passed the whole Cselect object
//  from which you probably want .id and .selected

class Cselect{
  
  // AttachTo is a parent DOM element id.  Actually appended to.
  // Id is the id of this element
  // Label (optional) is the adjecent tag text
  // Hint is optional tool-tip text.
  // OnChanged is optional function to execute when clicked.  This will
  //  be given the Cselect object.  From this you might want to access
  //  .id and .value
  //----------------------------------------------------  
  constructor(AppendTo,Id,Label,OptionsText,Hint,OnChanged){
    this.appendTo = AppendTo;   // parent attachment id
    this.id = Id;
    this.label = Label;   // can be ''
    this.options = OptionsText.split(',').map(V=>V.trim());
    if(this.options.length<1){throw "Crotator needs options";}
    this.selected = this.options[0];
    this.title = (Hint) ? ' title="'+Hint+'" ' : '';
    this.onChanged = (typeof OnChanged=='function') ? OnChanged : null;  // action on changed 
    $('#'+this.appendTo).append(this.Html());
    $('#'+this.id).change(this,Cselect.HandleClick);
  }  

  // Once-off HTML.  Will be tweaked by SetState etc.
  //----------------------------------------------------  
  Html(){
    var opts = this.options.map(function(O){
      var sel = (O==this.selected) ? ' selected ' : '';
      return '<option value="'+O+'"'+sel+'>'+O+'</option>';
    },this).join('/n');
    var h = '<span class="selector">'+this.label+'<br><select id="'+this.id+'"'+this.title+'>\n'+opts+'\n</select>';
    return h;
  }

  
  //--------------------------------------------
  SetOption(IxOrText){
    var ix = (typeof IxOrText == 'string') ? this.options.indexOf(IxOrText) : IxOrText;
    this.selected = this.options[ix % this.options.length];
    this.Repaint();
  }  

  // change text
  //--------------------------------------------  
  Repaint(){
    var el = $('#'+this.id);
    el.val(this.selected);
  }
  
  
  // Flips the state of the tickbox identified via the 
  //  .data slipped into the event.  Then calls the
  //  onChanged function.  
  //----------------------------------------------------  
  static HandleClick(Ev){
    var selector = Ev.data;
    var ctrl = $(Ev.target);
    selector.selected = ctrl.val();
    selector.onChanged(selector);
  }
  
  
}
