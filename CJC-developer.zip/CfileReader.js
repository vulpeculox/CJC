// Read and explore files on server.
// !NOTE! anything other than simple reads of specific files depends on being able to read directory indexes
//        so index.htm etc. will screw you up
// 		  You also need to make sure your server allows you to browse indexes.

class CfileReader{
  // Context is usually this. It's the context used to execute the follow-up functions
  //----------------------------------------------------------------------------------
  constructor(Context){
    this.context = Context;
    this.readFileQueue = [];
    this.afterAllReadsDo = null;
    this.afterEachReadDo = null;
    this.filesToDoCount = -1;
    this.sortByDate = 0;     // 0=alpha 1=latest at top -1 = latest at bottom
  }



  // Complete read of an array of files.
  // FilesToRead can be a single name, names separated by commas or an array.
  // ThenDoEach is a function(Data,Filename) to call after each read  (or use null).
  // ThenDoAll is an optional function() to call when finished.
  //--------------------------------------------------------------------------------
  ReadFiles(FilesToRead,ThenDoEach,ThenDoAll){
    var fa = (typeof FilesToRead == 'string') ? FilesToRead.split(',') : FilesToRead;
    this.readFileQueue = fa; //.map(this._FullName,this);
    this.filesToDoCount = this.readFileQueue.length;
    this.afterEachReadDo = ThenDoEach;
    this.afterAllReadsDo = ThenDoAll;
    if(this._TestEndOfAllReads()==false){       // possibly an empty array
      this.readFileQueue.forEach(function(V){
        this._ReadFile(V);},this);
    }
  }

  // Have we read everything?
  // If so call the ThenDoAll function
  // Return true if nothing more to do
  //----------------------------------
  _TestEndOfAllReads(){
    if(this.filesToDoCount<1){
      if(typeof this.afterAllReadsDo == 'function'){
        this.afterAllReadsDo.call(this.context);
      }
      return true;
    }
    return false;
  }

  // Read next file in queue (jquery)
  // When read call 'each' completion function
  _ReadFile(Fname){
    var fr = this;
    $.ajax({
      url:Fname,
      cache:false,
      mimeType:"text/html",                 // shuts-up ff dev tools
      dataType:"text"                       // essential
    })
    .fail(
      function(X,S,M){
        throw '_ReadFile('+Fname+') failed\n'+M;
    })
    .done(
      function(D,S,X){
        if(Fname.substr(-5)=='.json'){D = JSON.parse(D);}
        if(typeof fr.afterEachReadDo == 'function'){
            fr.afterEachReadDo.call(fr.context,D,Fname);
        }
        fr.filesToDoCount--;
        fr._TestEndOfAllReads();
    });
  }


  // Find files in a given path then process per ReadFiles().
  // PathToScan is relative with trailing slash  eg './tests/scripts/'
  // NameFilter is may be
  //   null ... all
  //   string ...  list of type of file !excluding! dot eg "htm|html|js"
  //   RegExp ...  Note: Use ^ for start of name eg to match foo.js not oldFoo.js
  // ThenDoEach is a function(Data,Filename) to call after each read
  // !Special case! if ThenDoEach is false then the list of matching files
  //  will be passed to ThenDoAll as a sorted array
  // ThenDoAll(array) is a function to call when finished
  // !Important!  This will be screwed-up if anything like index.html exists
  //  or directory listings have been turned-off by the server
  //----------------------------------------------------------------
  ReadPath(PathToScan,NameFilter,ThenDoEach,ThenDoAll){
    var fr = this;
    PathToScan = PathToScan;
    //PathToScan +='Hurdles/';  //@@@
    //@@@console.log('P',PathToScan);
    $.get({
      url:PathToScan,
      cache:false,
      mimeType:"text/html",                 // shuts-up ff dev tools
      dataType:"text"                       // essential
    })
    .fail(
      function(X,S,M){
        throw 'ReadPath('+PathToScan+') failed\n'+M;
    })
    .done(
      function(Data,S,X){
        var files = [];
       //@@@console.log(Data);

        // Does the data look like a index file
        /* APACHE
          if(Data.includes('Index of') && Data.includes('Last modified')){

              // stage 1 filter all useful lines.  ALL files, dirs and dir itself
              var lines = Data.split('\n').filter(function(V){return V.includes('href=');});
              var rows = lines.map(function(V){
                var rv = false;
                var trs = V.split('<td');
                if(trs.length==6){
                  var fn = trs[2].split('"')[1];  // filename
                  var ts = trs[3].substr(15,16);   // timestamp
                  //console.log('fnts',fn,ts);
                  return [fn,ts];
                }else{
                  //console.log('r','FALSE',V);
                  return false;
                }
              });
              rows.shift();  // get rid of parent dir
          */

          // NGINX
          if(Data.includes('Index of')){

              // stage 1 filter all useful lines.  ALL files, dirs and dir itself
              var lines = Data.split('\n').filter(function(V){return V.includes('href=');});
              var rows = lines.map(function(V){
                var rv = false;
                var a = V.split('>');
                if(a.length==3){
                  var fn = a[1].split('<')[0];  // filename
                  var tss = a[2].trim();        // timestamp in dd-mmm-yyyy hh:mm
                  //console.log('fnts',fn,ts);
                  return [fn,tss];
                }else{
                  //console.log('r','FALSE',V);
                  return false;
                }
              });
              rows.shift();  // get rid of parent dir

          //@@@console.table(rows);



              // stage 2 filter those matching extension or "/"
              // each row is [filename,timestamp]
              //console.log('IF',rows);

              var goodRows = rows.slice();   // default is everything
              if(typeof NameFilter == 'string'){
                // list of extensions we allow  eg '.js.htm.css'
                goodRows = rows.filter(function(V){
                  var rv = false;
                  if(V!==false){
                    var nameExt = V[0].split('.');
                    if(nameExt.length>1){
                      rv = NameFilter.includes(nameExt[1]);
                    }
                  }
                  return rv;
                });
              }else{
                if(NameFilter instanceof RegExp){
                  // match by regex
                  goodRows = rows.filter(function(V){
                    var rv = false;
                    if(V!==false){
                      rv = NameFilter.test(V[0]);
                    }
                    return rv;
                  });
                }
              }
              //console.log('e',NameFilter);
              //console.log('r',rows.join('\n'));
              //console.log('g',goodRows.join('\n'));


              // stage 3 sort
              var sorter = goodRows.map(function(V){
                if(fr.sortByDate===0){
                  return V.join('\n');
                }else{
                  return V[1]+'\n'+V[0];
                }
              });
              sorter.sort();
              if(fr.sortByDate==-1){sorter.reverse();}

              // stage 4 return simple list of files
              files = sorter.map(function(V){
                var va = V.split('\n');
                var n = (fr.sortByDate===0) ? va[0] : va[1];
                return PathToScan+n;
              });
        }// skipped all that if it didn't look like an index file
        //console.log('rpx',fr instanceof CfileReader,(ThenDoEach === false));

        if(ThenDoEach === false){
          //console.log('frcon',fr.context);
          //console.log('tda',ThenDoAll,ThenDoAll.name);
          if(ThenDoAll){
            if(ThenDoAll.name == '_UseResultsOfDiscovery'){
              //console.log('a');
              ThenDoAll.call(fr,files);
            }else{
              //console.log('b');
              ThenDoAll.call(fr.context,files);
            }
          }
        }else{
          fr.ReadFiles(files,ThenDoEach,ThenDoAll);   // send list to ReadFiles
        }
      }
    );

  }


  // Get a list of sub-dirs.
  // PathToRead can be relative to the current page.
  // ThenDo is a required function which takes three arguments:
  //   The *path* as given here
  //   The *actual path* as reported by the server.  This can be ERROR if for example
  //   there is an index.htm file present you'll not get a listing
  //   An *array of sub-directories* which may be zero length
  //-------------------------------------------------------------
/*  ListDirs(PathToRead,ThenDo,Context){
    if(typeof ThenDo != 'function'){
      throw "ListDirs() needs a ThenDo function";
    }

    console.log('LD',this.context.containerId);

    var fr = this;                       // the .fail and .done routines need a reference
    if(Context){fr.context = Context;}   // to the context to operate in when continuing calls
*/
  ListDirs(PathToRead,ThenDo){
    if(typeof ThenDo != 'function'){
      throw "ListDirs() needs a ThenDo function";
    }

    var fr = this;                       // the .fail and .done routines need a reference

    $.ajax({
      url:PathToRead,
      cache:false,
      mimeType:"text/html",                 // shuts-up ff dev tools
      dataType:"text"                       // essential
    })
    .fail(
      function(X,S,M){
        ThenDo.call(fr,PathToRead,'ERROR:'+M,[]);
        throw 'ListDirs('+PathToRead+') failed.';
    })
    .done(
      function(D,S,X){
        var a = D.split('\n');
        //console.table(a);

        // directory lines
			  //APACHE
				//	var da = a.filter(function(V){return V.includes('[DIR]'); });
				// NGINX
        var da = a.filter(function(V){return V.startsWith('<a') && V.includes('/">'); });
        // get the sub-path
        var dirs = da.map(function(V){
          var m = V.match(/href="([^"]+)"/);
          return m[1];
        });

				//console.table(dirs);
        // what path are we looking at
        var pfound = 'ERROR';
        var dp = a.filter(function(V){return V.includes('<h1>'); });
        if(dp.length>0){
					dp[0]= dp[0].split('</h1>')[0];
          // "<h1>Index of /test/2017</h1>"
          var sa = dp[0].split('/');
          //console.log('S',sa);
          sa.shift();   // lose first bit
          sa.pop();     // lose last bit
          pfound = '/'+sa.join('/');
          // APACHE  pfound = pfound.substring(0,pfound.length-1);
          //console.log('P',pfound);

        }
        ThenDo.call(fr,PathToRead,pfound,dirs);
      });
  }

  //======================================================
  //  EXPLORE DIRECTORIES
  //======================================================

  // Collect all sub-directories to the BasePath
  // return the path and sub-dirs as an array to ThenDo function
  //------------------------------------------------------------
  ExploreDirs(BasePath,ThenDo){
    this.pathsToExplore = [BasePath];
    this.pathsExplored = [];
    this.afterExploringDo = ThenDo;
    this._ExploreDirsA.call(this);
  }
  // sub-process of ExploreDirs
  //...........................
  _ExploreDirsA(){
    // if nothing left in the to-do queue then finish
    if(this.pathsToExplore.length<1){
      this.afterExploringDo.call(this,this.pathsExplored);
      return;
    }
    // get the next path to look at and list it's sub dirs
    var p = this.pathsToExplore.shift();
    this.ListDirs.call(this,p,this._ExploreDirsB);
    return;
  }
  // sub-process of ExploreDirs
  //...........................
  _ExploreDirsB(Path,ActPath,SubDirs){
    this.pathsExplored.push(Path);
    if(ActPath != 'ERROR'){
      SubDirs.forEach(function(V){
        this.pathsToExplore.push(ActPath+'/'+V);
      },this);
    }
    this._ExploreDirsA();
    return;
  }

  //======================================================
  // DISCOVER FILES
  //======================================================

  // This is a combination of exploring directories and reading files in a path
  // NameFilter may be
  //   null ... all
  //   string ...  list of type of file !excluding! dot eg "htm|html|js"
  //   RegExp ...  Note: Use ^ for start of name eg to match foo.js not oldFoo.js
  DiscoverFiles(BasePath,NameFilter,ThenDoEach,ThenDoAll){
    //console.log('df',this instanceof CfileReader);

    this.extToMatch = NameFilter;
    this.doEach = ThenDoEach;
    this.afterDiscoveryDo = ThenDoAll;
    this.discoveredFiles = [];
    this.ExploreDirs(BasePath,this._BeginDiscovery);
  }

  _BeginDiscovery(PathsArray){
    //console.log('bd',this instanceof CfileReader);
    this.pathsToDiscover = PathsArray;
    this._ContinueDiscovery();
  }

  _ContinueDiscovery(){
    //console.log('cd',this instanceof CfileReader);
    if(this.pathsToDiscover.length<1){
      this.afterDiscoveryDo.call(this.context,this.discoveredFiles);
      return;
    }
    var p = this.pathsToDiscover.shift();
    this.ReadPath(p,this.extToMatch,this.doEach,this._UseResultsOfDiscovery);
  }

  _UseResultsOfDiscovery(FileNameArray){
    //console.log('urod',this instanceof CfileReader);

    this.discoveredFiles = this.discoveredFiles.concat(FileNameArray);
    this._ContinueDiscovery();
  }



  /*(AddModifiedDate(FileOrFiles){
    var fof = ArrayIsArray(FileOrFiles) ? FileOrFiles : FileOrFiles.split(',');
    fof.forEach(function(V){
      fetch(V).then(function(



    },this);  */




  // get current file and see if it's changed
  //-------------------------------------------------------------------
  _TestCurrentFile(){
    var cwthis = this;
    $.ajax({
      url:this.files[this.fileIndex][0],
      cache:false,
      timeout: 2000,
      ifModified:true,                        // essential
      mimeType:"text/html",                   // shuts-up ff dev tools
      dataType:"text"                         // essential
    })
    .fail(function(X,S,M){
      cwthis.files[cwthis.fileIndex][1] = 'ERR';
      cwthis._ContinueScan();
    })
    .done(function(D,S,X){
      // last modified string
      //var lm=X.getAllResponseHeaders().split('\n').filter(V=>V.includes('Last-Modified:'))[0].substr(15).trim();
      // TypeError: X.getAllResponseHeaders(...).split(...).filter(...)[0] is undefined[Learn More]

      //console.log('['+lm+']');
      //@@@@@@ don't know how to put this info to good use

      //console.log('OK',cwthis.files[cwthis.fileIndex][0],X.status);
      cwthis.files[cwthis.fileIndex][2] = Date.now();   // timestamp tested
      cwthis.files[cwthis.fileIndex][1] = (cwthis.firstScan) ? '304' : ''+X.status;
      cwthis._ContinueScan();
    });
  }

  // Return js date or string if an error
  static LastModified(URL){
    var lms;
    try{
      var xr = new XMLHttpRequest();
        xr.open("HEAD", URL, false);
        xr.setRequestHeader('Cache-Control', 'no-cache');
        xr.send(null);
        if(xr.status==200){
          lms = xr.getResponseHeader('Last-Modified');
          return new Date(lms);
        }
        else return false;
    } catch(er) {
        return er.message;
    }
  }


}



