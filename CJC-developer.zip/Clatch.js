// Latching button 

class Clatch{
  
  // AttachTo is a parent DOM element id.  Actually appended to.
  // Label is the id of this element
  // Hint is optional tool-tip text.
  // Ticked is true if X and tick are added 
  // OnChanged is optional function to execute when clicked.  This will
  //  be given the Clatch object.  From this you might want to access
  //  .id and .isDown
  //----------------------------------------------------  
  constructor(AppendTo,Label,Text,Hint,Ticked,OnChanged){
    this.appendTo = AppendTo;   // parent attachment id
    this.id = Label.trim();
    if((/[A-Za-z0-9]+/.test(this.id))===false){throw "Clatch needs a better Label";}
    this.text = Text.trim();
    if(this.text.length<1){throw "Clatch needs text";}
    this.title = (Hint) ? ' title="'+Hint+'" ' : '';
    this.ticked = (Ticked) ? ' tick' : '';
    this.onChanged = (typeof OnChanged=='function') ? OnChanged : null;  // action on changed 
    $('#'+this.appendTo).append(this.Html()).on('click','#'+this.id,this,Clatch.HandleClick);
    this.isUp = true; 
  }  

  // Once-off HTML.  Will be tweaked by SetState etc.
  //----------------------------------------------------  
  Html(){
    return '<span id="'+this.id+'"'+this.title+' class="latch up'+this.ticked+'">'+this.text+'</span>\n';
  }

  
  // sets state to up or down
  // DownBool is boolean true for depressed
  // Changes the display but nothing is trigered
  //--------------------------------------------
  SetState(DownBool){
    this.isUp = (DownBool) ? false : true;
    this.Repaint();
  }  

  get isDown(){
    return !this.isUp;
  }
  
  // change css
  //--------------------------------------------  
  Repaint(){
    var el = $('#'+this.id);
    if(this.isUp){
      el.addClass('up').removeClass('down');
    }else{  
      el.addClass('down').removeClass('up');
    }
  }
  
  
  // Flips the state of the tickbox identified via the 
  //  .data slipped into the event.  Then calls the
  //  onChanged function.  
  //----------------------------------------------------  
  static HandleClick(Ev){
    var latch = Ev.data;
    latch.isUp = !latch.isUp;
    latch.Repaint();
    latch.onChanged(latch);
  }
  
  
}
