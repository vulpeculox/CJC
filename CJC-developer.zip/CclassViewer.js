//  CLASS FILE PARSER
//  Parses source of a file
//  Makes useful information available


// static methods

class CclassViewer{
  
  // how do we sort different element types?
  // return K-V for looking-up sort order
  static SortPrefix(Type){          
    switch(Type){
    case 'CONSTRUCTOR' : return 'a';
    
    case 'METHOD' : return 'c';
    
    case 'THIS' :
    case 'SET' : 
    case 'GET' :  return 'd';

    case 'STATIC-GET' :    // static-set doesn't make sense
    case 'STATIC-METHOD' : return 'b';
    
    default : return 'x';
    }  
  }

  
  static TypeToNameClasses(Type){
    switch(Type){
    case 'CONSTRUCTOR' : return 'constructor imgc';
    case 'GET' : return 'get imgGetProp';
    case 'METHOD' : return 'method imgf';
    case 'SET' : return 'set imgSetProp';
    case 'STATIC-GET' : return 'static-get imgp';
    case 'STATIC-METHOD' : return 'static-method imgf';
    case 'THIS' : return 'this imgProp';
    default : return 'x';
    }
  }


  // complete fancification of comments
  // Returns an array of fancified strings
  //-----------------------------------
  static FormatComments(Comments,Args,SkipHighlighting){
    
    // ~~~ part 1 : layout, wrapping etc ~~~
    // Wrapping rules:
    //  1 space at start of line --> New line
    //  2 spaces at start of line --> concat with prev (wrap)
    //  >2 spaces --> New line then spaces
    
    var joined = [];
    // weirdly we seem to be getting comment lines such as "//  null" appearing here as null!
    // the same goes for "// true" and "// false"
    var c = Comments.map(function(V){
      if(typeof V != 'string'){
        console.log('Non-string in comments ['+V+']'+typeof V);
        V=V.toString();
      }
      return V.substr(1);
    });  // lose leading space
    c.forEach(function(V){
      if(V.startsWith('  ')){
        joined.push(V);
      }else{
        if(V.startsWith(' ')){
          var jcl = joined.length-1;
          if(jcl<0){
            joined.push(V.trim());
          }else{  
            joined[jcl]+=' '+V.trim();
          }
        }else{
          joined.push(V);
        }
      }
    });
    
    // everything is now starting on the correct line except we may have
    // some very long lines that need to overflow.
    const wrapWidth = 60;
    var joinedArray = joined.map(function(V){
      var rv = [];
      var thisLine = '';
      var sm = V.match(/^( +)/);       // how many spaces at start of line
      var indent = (sm) ? sm[1] : '';  // this is our wrapping guide  
      var words = V.trim().split(/\s/);
      thisLine = indent;
      words.forEach(function(W){
        if((thisLine.length + W.length + 1) > wrapWidth){
          rv.push(thisLine);
          thisLine=indent;
        }
        thisLine += ' '+ W;
      });  
      if(thisLine.trim().length>0){rv.push(thisLine);}
      return rv;
    });
    
    // flatten into a single array then we're all wrapped and ready
    c = [];
    joinedArray.forEach(function(V){
      c = c.concat(V);
    });  
    
    c = c.map(function(V){return V.replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&#x00022;');});
    
    if(SkipHighlighting === true){return c;}
    
    // ~~~ part 2 : html highlighting ~~~
    
    var reRet =  new RegExp('(returned|returns|return)','gi');   // return
    var reKey =  new RegExp('(true|false|undefined|null)','g');  // special words 
    var reExcl = new RegExp('!([^!]+)!','g');                   // !...!  --> note
    var reNote = new RegExp('(Note:)','g');                     // Note:  --> note
    var reStar = new RegExp('\\*([^\\*]+)\\*','g');             // *...*  --> highlight
    var reQuo =  new RegExp('\"([^"]+)"','g');                  // "..."  --> highlight
    
    var reProp = new RegExp('(\\.[\\w()]+)','g');               // .prop or .meth() 
    var reCode = /^\s*(\|)/;                        // | ...  --> code for rest of line
    var rxsErr = false;
    var rxs = Args.map(function(A){
      var a = '('+A.trim()+')(\\W)';
      var rv = new RegExp('DUMMYDUMMY');
      try{
        rv = new RegExp(a,'g'); 
      }catch(e){
        rxsErr = [a,Comments];
      } 
      return rv;
      
    });
    
    
    c = c.map(function(V){
      var rv = V;
      rxs.forEach(function(R){
        rv = rv.replace(R,'<span class=funArg>$1</span>$2');
      });
      if(reCode.test(rv)){
        rv = rv.replace(reCode,' <span class=codeExample>') + '</span>';
      }else{
        rv = rv.replace(reRet,'<span class=ret>$1</span>');
        rv = rv.replace(reKey,'<span class=bold>$1</span>');
        rv = rv.replace(reExcl,'<span class=note>$1</span>');
        rv = rv.replace(reNote,'<p class=note><span class=note>$1</span>');
        rv = rv.replace(reStar,'<span class=star>$1</span>');
        rv = rv.replace(reQuo,'"<span class=quoteString>$1</span>"');
        rv = rv.replace(reProp,'<span class=dotProp>$1</span>');
      }  
      //return rv;
      return rv.substr(1);  //<-remove 1 leading space
    });      
    
    if(rxsErr!==false){
      c =     '<span class=invert>~~~FORMATTING PROBLEM:Possibly add another space before = to prevent this.  '+rxsErr[0]+' ~~~</span><p>' + c;
    }
    
    return c;
  }
  
}      





/*                                                                                         
  ______      _                 _______ _ _       ______                                 
 / _____)    | |               (_______|_) |     (_____ \                                
| /      ____| | ____  ___  ___ _____   _| | ____ _____) )___  ____ ___  ____  ____      
| |     / ___) |/ _  |/___)/___)  ___) | | |/ _  )  ____/ _  |/ ___)___)/ _  )/ ___)     
| \____( (___| ( ( | |___ |___ | |     | | ( (/ /| |   ( ( | | |  |___ ( (/ /| |         
 \______)____)_|\_||_(___/(___/|_|     |_|_|\____)_|    \_||_|_|  (___/ \____)_|         
=========================================================================================                                                                        
*/

  
class CclassFileParser{

  // Create a bare shell.  We will give it the source later
  // but for now tell it the filename.
  //-------------------------------------------------------
  constructor(FileName){
    this.fileName = FileName;
    this.parseTimestamp = new Date();   
    this.parseErrors = [];
    this.topComments = [];   // File description
    this.classes = [];
    this.commentBuffer = [];
    this.rxs = {     // regexs to look for code blocks
      'class': /^class\s+(\w+)\s?(extends)?\s?(\w+)?/,
      'constructor': /^constructor\(([^\)]*)\)/,
      'get': /^(static)?\s*get\s*(\w+)\(\)/,
      'set': /^set\s*(\w+)\(([^\)]*)\)/,                   
      'method': /^(static)?\s*(\w+)\(([^\)]*)\)/
    };  
    this.codeSpyRxs = {                 // regexs to look at code
      'newKeyword' : /new\s(\w+)/,      // Note: leave this as single space to allow bypassing if not wanted
      'topThis' : /^this.(\w+)\s=/,     // Note: leave this as single spave to allow bypassing if not wanted
      'impExp'  : /CJC\.Register/       // Often appears at bottom of sources to register classes with CJC
    };  
    this.ignoreNews = 'Date|RegExp|Array|String|Promise|XMLHttpRequest|Map';   // These don't trigger a listing in the dependencies
    this.currentlyInConstructor = false;
  }

/*  ExportClasses(){
    this.classes.forEach(function(V){
      var j = V.toJson();
      
  */    
  
  
  ExportSource(){
    return new Csource(this.fileName,this.topComments,this.ClassList(),this.parseTimestamp);
  }
  
  ClassList(){
    return this.classes.map(V=>V.name).sort();
  }    
  
  // run through source top to bottom
  //---------------------------------
  ParseSource(Source){
    this.currentClass=false;
    this.braceLevel = 0;
    this.inSlashStars = false;
    this.atTop = true;  
    var srceArray = Source.split('\n');
    srceArray.forEach(this._ProcessLine,this);      // call the hard-working bit
    if(this.currentClass){this.classes.push(this.currentClass);}
    return (this.parseErrors.length === 0);
  }

  // examine a single line
  //----------------------------------
  _ProcessLine(Text,LineNum){  
    var code,comment,ext,currentlyInConstructor,key; 
    this.lineNum = LineNum;
    
    // get rid of /*....*/
    if(Text.includes('/'+'*')){this.inSlashStars = true;}   // oddity to prevent / * triggering false hits when parsing this file
    if(this.inSlashStars){
      if(Text.includes('*'+'/')){this.inSlashStars = false;}  // ditto
      return;   // nothing more to do    
    }
    
    // blank lines are important.  Clear out comment buffer, mark end of top comments
    var line = Text.trim();
    if(line===''){
      if(this.atTop){
        this.atTop = false;
      }else{
        this.commentBuffer = [];
      }  
      return;   // nothing more to do
    }

    // split code and comments
    var dsix = line.indexOf('//');
    switch(dsix){
    case -1 : code = line; comment = ''; break;     //    all code
    case 0  : code = ''; comment = line.substr(2); break;     //    all comment
    default : code = line.substr(0,dsix); comment = line.substr(dsix+2);
    }
    //if(comment){console.log(this.lineNum,code+']['+comment);}
    // blocks of comments will be stacked to be put onto elements
    if((code==='')&&(comment !=='')){
      if(this.braceLevel<=1){     // ignore deep nestings
        switch(comment[0]){
        case '.' :  // @@@ eventually this will be developers comments, tags etc 
        case ' ' :  if(this.atTop){
                      this.topComments.push(comment);
                    }else{
                      this.commentBuffer.push(comment);
                      if(typeof comment != 'string'){
                        console.log('ZZZZZZ',LineNum,comment);
                      }  
                        
                    }
                    break;
        default :   // throw away comments if something follows immediately after slashes
        }
      }  
      return;
    }

    // always look for new Cfoo at any brace level
    var newm = code.match(this.codeSpyRxs.newKeyword);
    if(newm){
      var newC = newm[1];  // new class name
      //console.log('NEWC',this.lineNum,newC,line);
      if(this.ignoreNews.includes(newC)===false){
        if(this.currentClass===false){
          console.error('Found the new keyword outside of a class.\nProbably not a class');
          return;
        }  
        if(this.currentClass.dependsOn.includes(newC)===false){
          this.currentClass.dependsOn.push(newC);
        }
      }      
    }  
    // test for special case CJC (proper class jsoning) 
    // (This is a hard code hack which others might want to tweak)
    if(this.braceLevel===0){
      if(this.codeSpyRxs.impExp.test(code)){
        this.currentClass.dependsOn.push('CJC');
      }  
    }  
      
    
    //--------------------------------------------------------------
    // don't bother any syntactic analysis below block level except
    //  1     throw if we're already nested    
    //  2     this.foo = bar;  // fox 
    //--------------------------------------------------------------
    if(this.braceLevel>1){
      // --==THROW==--
      var thr = code.search(/throw /);          // test for throw...
      if(thr>-1){
        var ts = code.substr(thr+5);
        var scix = ts.indexOf(';');
        if(scix>4){ts = ts.substr(0,scix);}
        ts = ts.trim();
        this.currentClass.AddThrow(this.lineNum,ts,comment);
      }
      // --==THIS==--
      if(this.currentlyInConstructor){
        var thisM = code.trim().match(this.codeSpyRxs.topThis);
        if(thisM){
          var thisVar = thisM[1];  // var name
          var a = code.split('=').map(V=>V.trim());   // should be [this.foo,some-val]
          var initMaxLen = 30;
          var init = a[1].substr(0,initMaxLen);
          if(init.endsWith(';')){init = init.substring(0,init.length-1);}  // lose trailing ;
          if(init.length==initMaxLen){init+='...';}
          if(init.startsWith('(')){init='';}   // ignore  (foo==bar)?baz:fox;
          this.currentClass.AddElement(this.lineNum,'THIS',thisVar,init,[comment]);
          //console.log('this',this.lineNum,thisVar,comment);
        }  
      }  
      
      
      // that's the only bit of code we care about
      this._AdjustbraceLevel(code);
      return;
    }
    
    // let's look for key words
    //console.log(this.lineNum,this.braceLevel,code,comment);
    key = 'none';
    ['class','constructor','get','set','method'].some(function(V,I){
      var hit = this.rxs[V].test(code);
      if(hit){key = V;}
      if(this.braceLevel===0){
        // brace level-0 is out of class so...
        //only ever bother with class
        return true;
      }  
      return hit;
    },this);
    if(key=='none'){
      this._AdjustbraceLevel(code);
      return;
    }

    
    
    // we can fiddle with the brace level now and get that chore out of the way   
    this._AdjustbraceLevel(code);
    
      
    // check what we've found is inside a class
    if((key != 'class')&&(this.currentClass===false)){
      this._AddError('Keyword '+key+' found outside of class');
      return;
    }
      
    var matches = this.rxs[key].exec(code);    // [0] = full text 
    
    this.currentlyInConstructor=false;
    switch(key){
      case 'class' :     // (name)...(extends)?
        ext = 'XXX';
        if(this.currentClass){this.classes.push(this.currentClass);}
        ext = (matches[3]) ? matches[3] : '';    
        //console.log('m',matches.length,ext,'['+matches.join('|')+']');
        this.currentClass = new CclassDef(this.lineNum,matches[1],ext,this._UseComments(),this.fileName);
        break; 
      case 'constructor' :  // (args)
        this.currentlyInConstructor=true;
        this.currentClass.AddElement(this.lineNum,'CONSTRUCTOR','-',matches[1],this._UseComments());
        break;
      case 'get' :  // (static)? ... (name)
        if(matches[1]=='static'){
          this.currentClass.AddElement(this.lineNum,'STATIC-GET',matches[2],[],this._UseComments());
        }else{
          this.currentClass.AddElement(this.lineNum,'GET',matches[2],[],this._UseComments());
        }
        break;
      case 'set' :  // (name)   Static version doesn't make sense
      console.log('set',code);
      
        this.currentClass.AddElement(this.lineNum,'SET',matches[1],matches[2],this._UseComments());
        break;
      case 'method' :   //(static)?...(name)...(args) 
        if(matches[1]=='static'){
          this.currentClass.AddElement(this.lineNum,'STATIC-METHOD',matches[2],matches[3],this._UseComments());
        }else{
          this.currentClass.AddElement(this.lineNum,'METHOD',matches[2],matches[3],this._UseComments());
        }
        break;
    }  
    
    return;     
      
  }  

  // get and flush comments from buffer
  _UseComments(){
    var rv = this.commentBuffer;
    this.commentBuffer = [];
    return rv;
  }  
  


  // this looks for juicy key words
  //-------------------------------      
  _ParseLine(Blevel,State,Code,Comment){
    //@@@@@@@@@@@@
    return ['x',-1,Code,Comment];
  }  

  // Add an error message to array
  //------------------------------
  _AddError(Msg){
    this.parseErrors.push([this.lineNum,Msg]); 
  }  
    
    
  // count the opening and closing braces so we know when 
  // we're in global scope etc. 
  // If we get to 0 set scope to global
  // If we get to < 0 that's an error
  //------------------------------------------------------------
  _AdjustbraceLevel(Line){
    var newBl;
    var ob1 = Line.indexOf('{');      // any opening brace
    var cb1 = Line.indexOf('}');      // any closing brace
    if((ob1<0)&&(cb1<0)){return;}   // nothing to do
    
    // avoid quotes and regexpisms
    var s = ' ' + Line.replace(/(\/\S*\/)/g,'');   //remove regex
    s = s.replace(/"[^"]*"/g,'');                  // remove double quotes
    s = s.replace(/'[^']*'/g,'');                  // remove single
    var bdif = (s.match(/\{/g)||[]).length - (s.match(/\}/g)||[]).length;

    //console.log('bl',Blevel,bdif,Line);
    
    if(bdif !==0){ 
      this.braceLevel += bdif;
      if(this.braceLevel < 0){
        this._AddError('Accumulation of too many closing braces');
        this.braceLevel=0;
      }  
    }  
  }


  
}
  