// Generic index of keyed objects
// All objects must have some sort of unique ID, normally just .id 
//. Requires ArrayAddons.js

// IMPORTANT USAGE NOTE
// The objects stored in the index are *references* which means that
//  external objects can hack the data and will be altered if the indexed
//  records are changed.  For example:
//   myObj = new Obj();
//   myObj.foo = 'FOO';
//   myIx.Add(myObj);
//   myObj.foo = 'MORE FOO';
//   myIx.Get(something).foo ==> 'MORE FOO'
//   myIx.Update(something,{foo:'NO FOO!'});
//   myObj.foo ==> 'NO FOO!' 
// This is excellent if you want to fetch then change a local object, but 
//  remember that the index won't know it's been changed.
//
// DO NOT UNDER ANY CIRCUMSTANCES change the .id (etc) of any object locally
//
// Note:  Even with the id set to auto (which gives a random number) ids are *always* strings
class Cindex{

  // IdMethod is property name of record object or some function taking a record object.
  // If IdMethod is blank then "AUTOMATIC" is assumed.
  // IdMethod can be "AUTOMATIC" which allocates .id a one-time random numeric identifier
  // IdMethod can be "INCREMENTAL" which allocates .id starting with 0  Note:  DO NOT use an .id to index
  //  into .records as there is no guarantee there is a match. 
  // UniqueFields is an array (always an array if present) of string property names. 
  //---------------------------------------------------------------------------------
  constructor(IdMethod,UniqueFields){
    this._records = [];  // } kept in sync with ._keys
    this._keys = [];    // } kept in sync with .records
    this.changed = false;
    this.autoId = (arguments.length===0) ? 'a' : false;  // no args is (a)utomatic else default to false
    this.idMethod = 'id';
    this.IdFun = function(R){return R.id;};   // default
    this.uniqueFields = [];     // none by default  (id is always unique)
    this.maxRecord = 0;        // counter for incremental

    
    // sort out arguments.  The possibilities are:
    // (),(str/fun),(str/fun,array),(array)  Also allow for bad call (str,str)
    for(var aix=0;aix<arguments.length;aix++){
      switch(typeof arguments[aix]){
      case 'string' :
        if(aix===0){
          this.idMethod = arguments[aix];
          if(this.idMethod=='AUTOMATIC'){
            this.autoId = 'a';
            this.idMethod = 'id';
          }
          if(this.idMethod=='INCREMENTAL'){
            this.autoId = 'i';
            this.idMethod = 'id';
          }
          this.IdFun = function(R){return R[this.idMethod];};
        }else{
          this.uniqueFields = [arguments[aix]];
        }
        break;
      case 'function' :
        if(aix===0){
          this.IdFun = arguments[aix];
        }else{
          throw "Function is not acceptable as 2nd argument for Cindex constructor:";
        }
        break;
      default :     
        if(Array.isArray(arguments[aix])){
          this.uniqueFields = arguments[aix];
        }else{
          throw "Unsuitable argument given to Cindex constructor:"+arguments[aix];
        }  
      }
    }
    //console.log('NEWINDEX',this.IdFun,'\n',this.idMethod,this.uniqueFields,arguments);
    
    
    this.store = null;
    this.storeKey = null;
    this._saveInterval = 0;    // 0:no auto-save 1:every change >1: seconds between watchdog  NYI
    this._saveTimerId = false;

  }
 
  // Instant listing of elements in natural order
  // If Filter is provided then only return lines containg the strings.
  // Filter can be multiple match strings split by commas
  // Also Filter can be a (misleadingly) a mapping function returning a string
  // Note:  This always returns all the records even if there are no filter matches on them
  //------------------------------------------------------------------
  Dump(Filter){
    if(typeof Filter == 'function'){
      return this._records.map(Filter);
    }  
    
    var kvsa = this._records.map(function(V){    // array of records each an array of KVs
      return JSON.stringify(V).split(',');
    });
    
    // possibly filter
    if(typeof Filter != 'undefined'){
      var f = (typeof Filter == 'string') ? Filter.split(',') : f;
      kvsa = kvsa.map(function(KVS){
        var retEls = KVS.filter(function(KV){
          var rv = false;
          f.forEach(function(F){
            rv=rv||KV.includes(F);
          });
          return rv;}
        );
        return retEls;}
      );         
    }
    
    var a = kvsa.map(KVS=>KVS.join('\n'));
    return a.join('\n---------('+Filter+')-------------\n');
  }    

  
  // how many records in the index?
  //-------------------------------
  get length(){
    return this._records.length;
  }  
  
  ChangeAndSave(){
    this.changed = true;
    if(this._saveInterval == 1){this.Save();}
    // otherwise save manually or via timer setInterval
    return; 
  }    
  
  // ***UNTESTED***
  // How do we go about saving this?
  // Interval ... 0   Manual calls  (default)
  //          ... 1   Every change
  //          ... >1  Every n seconds (if required)  
  //-----------------------------------------------
  SetSavePolicy(Interval){
    if(this._saveTimerId){
      clearTimeout(this._saveTimerId);
      this._saveTimerId = false;
    }  
    this._saveInterval = Interval;
    if(Interval>1){
      this._saveTimerId = setInterval(this.Save,Interval*1000,this);
    }
  }    
  
  
  
  // ***NEEDS TESTING WITH SELF***
  // If changed then save to the store using values provided
  //  by store.GetOrCreate()
  //. Because we may be calling this from setInterval() we lose the proper
  //  this reference.  Hence the fannying around with Self
  //--------------------------------------------------------
  Save(Self){
    var self = (typeof Self != 'undefined') ? Self : this;
    if(self.changed){
      if(self.store instanceof Cstore){
        if(typeof self.storeKey =='string'){
          self.changed=false;
          self.store.Put(self.storeKey,self);
          return;
        }
      }
      throw "Cindex.Save() method failed.  Probably no .store/.storeKey";
    }
  }    
   
  // Tell the index it has changed
  // See usage note in class documentation.
  //--------------------------------------------------------------------------  
  FlagChanged(){
    this.changed = true;
  }  
  
  
  // Return false if id not present
  //-------------------------------
  Delete(Id){
    var ix = this._keys.indexOf(Id);
    if(ix == - 1){return false;}        // NOT FOUND!
    this._keys.splice(ix,1);
    this._records.splice(ix,1);
    this.changed = true;
    return true;
  }

  // Unique add
  // Return ID of new entry
  // Return false if id already exists except Force allows overwrite
  // See .Update()
  //----------------------------------------------------------------
  Add(Record,Force){
    if(this.autoId=='a'){
      Record.id = (Math.floor(Math.random() * 999999999999)).toString();
    }
    if(this.autoId=='i'){
      Record.id = this.maxRecord++;
    }
    var id = this.IdFun(Record); 
    var ix = this._keys.indexOf(id);
    if(ix >- 1){
      if(Force===true){
        this._records[ix]=Record;
        this.changed = true;
        return id;
      }else{
        return false;        // DUPLICATE!
      }
    }
    if(this.IsUnique(Record)){    
      this._keys.push(id);
      this._records.push(Record);
      this.changed = true;
      return id;
    }else{
      return false;
    }      
  }

  // Test any fields specified as unique for clashes
  // RecordOrValue can be a record which may have values set for its fields
  //  or a single (non-object) value which will be compared with all the unique fields
  //  for matching separately.
  // Returns false if any of a record's fields match their associated fields in the indexed data.
  // Returns false if a simple value matches any of the unique-fields
  // Returns true if no unique fields have been defined.
  // (Unique field names are specified in the constructor)
  //-------------------------------------------------------------------------------------
  IsUnique(RecordOrValue){
    if(this.uniqueFields.length === 0){return true;}  // nothing to do
    // object
    var testKeyVals;
    if(typeof RecordOrValue == 'object'){
      var objKeys = Object.keys(RecordOrValue);
      var fldsToTest = this.uniqueFields.intersection(objKeys); 
      if(fldsToTest.length ===0){return true;}   // none of unique fields in obj
      testKeyVals = fldsToTest.map(N=>[N,RecordOrValue[N]]);
      // now we have matching arrays of K and V which we can test against records
    }else{
      // value
      testKeyVals = this.uniqueFields.map(N=>[N,RecordOrValue]);
    }  
    var found = false;
    testKeyVals.forEach(function(KV){
      if(!found){    // short circuit one unique find
        found = this._records.map(R=>R[KV[0]]).includes(KV[1]);
      }  
    },this);
    return (found===false);
  }
  
  // An emergency function if somehow you think the keys in the index
  //  have got out of alignment with the id values in the records themselves.
  // This could happen as follows:
  // |   rec = ix.Get('MyKey');
  // |   rec.id = 'bla bla bla';    *BAD BAD BADDITY BAD*
  // At this point the key is 'MyKey' but the record.id in the index
  //  is 'bla bla bla'!   
  // |   againRec = ix.Get('bla bla bla');  ==> false
  EmergencyRebuild(){
    this._keys = this._records.map(function(R){
      return this.IdFun(R);
    },this);
    this.changed = true;
  }    
    
  
  // Return actual record or false if not found  
  Get(Id){
    var ix = this._keys.indexOf(Id);
    if(ix == -1){return false;}        // NOT FOUND!
    return this._records[ix];
  }
  
  
  // Get record and remove it from the index
  // at the same time
  //----------------------------------------
  Remove(Id){
    var rv = this.Get(Id);
    if(rv){
      this.Delete(Id);
    }
    return rv;
  }    


  
  // Look up the record then return specified field value (or undefined)
  GetField(Id,FieldName){
    var r = this.Get(Id);
    if(!r){return undefined;}
    return r[FieldName];
  }  
    
    
  
  // does the Id given exist  
  IdExists(Id){  
    return (this._keys.indexOf(Id) > -1);
  }  
    
    
  // Use the fields of the object to update the specified record.
  // Return false if record not found  
  //----------------------------------------------------
  Update(Id,Obj){
    if(this.IsUnique(Obj)===false){// trap unlawful duplicates
      console.log('NOT UNIQUE',Id,Obj);
      return false;
    }  
    var ix = this._keys.indexOf(Id);
    if(ix == - 1){return false;}        // NOT FOUND!
    Object.entries(Obj).forEach(function(KV){
      if(KV[0] != this.idMethod){       // don't allow changing id
        //console.log('kv',KV.join('|'));
        this._records[ix][KV[0]]=KV[1];
        this.changed = true;
      }  
    },this);
    return true;
  }
  
  // Return array of keys
  // Note: this is a !copy! of the keys
  // A complete list of keys is given with no arguments,
  //  but a sub-set can be obtained by passing the results of 
  //  this.Filter(...) to it. eg:
  // |  ListKeys(this.Filter('gender','M')); ==> men only
  //----------------------------------------------------
  ListKeys(OptionalFilterResult){
    if(Array.isArray(OptionalFilterResult)){
      if(OptionalFilterResult.length===0){return [];}
      return OptionalFilterResult.map(function(R){
        return this.IdFun(R);
      },this); 
    }    
    return this._keys.slice();
  }  
  
  
  // Return an array of doublets of the form [id,string]
  // PropOrMethod tells what the 2nd value will be.  It can
  //  be a string for a property such as "name" or a method
  //  such as say "GetName".  
  // OptionalFilterResult is an array of records being the
  //  result of .Filter()
  //----------------------------------------------------
  Doublets(PropOrMethod,OptionalFilterResult){
    if(this._keys.length<1){return [];}
    var isFun = this._IsMethod(PropOrMethod);
    var recs = (Array.isArray(OptionalFilterResult)) ? OptionalFilterResult : this._records;
    return recs.map(function(R){
      var id = this.IdFun(R); 
      var str = (isFun) ? R[PropOrMethod]() :  R[PropOrMethod];
      var rv = [id,str];
      return rv;
    },this);
  }
  
  // Doublets without the id 
  //------------------------
  Singlets(PropOrMethod,OptionalFilterResult){
    var ds = this.Doublets(PropOrMethod,OptionalFilterResult);
    return ds.map(V=>V[1]);
  }  
  
  
  
  // Return an array of matching records or empty array
  // PropOrMethod gives a value to be matched with Value.  It can
  //  be a string for a property such as "name" or a method
  //  such as say "GetName".  
  // See also .Find()  
  //---------------------------------------------------
  Filter(PropOrMethod,Value){    
    if(this._keys.length<1){return [];}
    if(arguments.length===0){
      return this._records.filter(V=>true);
    }  
    var isFun = this._IsMethod(PropOrMethod);
    return this._records.filter(function(R){
      return isFun ? R[PropOrMethod](Value) :  (R[PropOrMethod]==Value);
    });
  }
  
  
  // Name is a string which might refer to .Name or .Name(...)
  //  If the latter then we have to execute it later rather than
  //  just access the value.   
  //. We look at the first record's methods and properties
  //---------------------------------------------------------------
  _IsMethod(Name){
    if(this._records.length <1){return true;}  // we SHOULD have protected against this in the calling code
    return (typeof this._records[0][Name] == 'function');
  }
  
  // Return a single record or false.
  // Note: Use this when expecting a single definite result
  // PropOrMethod gives a value to be matched with Value.  It can
  //  be a string for a property such as "name" or a method
  //  such as say "GetName".  
  // see also .Filter()
  //---------------------------------------------------------------
  Find(PropOrMethod,Value){    
    if(this._keys.length<1){return false;}
    var isFun = this._IsMethod(PropOrMethod);
    var rv = this._records.find(function(R){
      return isFun ? R[PropOrMethod](Value) : (R[PropOrMethod]==Value);
    });
    if(typeof rv == 'undefined'){rv = false;}
    return rv;
  }
  
  // This wipes the index completely !both in memory and storage!
  //  Are you sure must be a three letter affirmative in upper case
  //---------------------------------------------------------------
  Wipe(AreYouSure){
    if(AreYouSure == 'YES'){
      this._records = [];  
      this._keys = [];     
      this.changed = true;
      this.Save();
    }
  }    
  
    

  // Utility to sort an array of doublets in place.
  // FieldNum is 1,-1,2 or -2 for first or 2nd field and up or down
  // For example a typical sort on [id,Name] would be 2
  //---------------------------------------------------------------
  static DoubletSort(Doublets,FieldNum){
    var f1 = (Math.abs(FieldNum)==1);
    var fdn = (Math.sign(FieldNum) == -1);
    Doublets.sort(function(A,B){
      var a = f1 ? A[0] : A[1];
      var b = f1 ? B[0] : B[1];
      var rv=0;
      if(a>b){rv = 1;}else{if(a<b){rv=-1;}}  
      if(fdn){rv=0-rv;}
      return rv;
    });
  }    
  
}  
    
CJC.RegisterConstructors([Cindex]);  
  
