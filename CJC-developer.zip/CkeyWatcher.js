// Lookup for key combinations which translate to functions or calling objects
// Better than a massive switch statement!
// Example with functions:
//   new KeyWatcher().AddWatch('_38',DoUP).AddWatch('SC_40',DoSCD);
//   . . . 
//   function DoUP(Evnt){console.log('Up',E.target);}
//
// Example with objects
//   new KeyWatcher().AddWatch('_38',buttons.up).AddWatch('SC_40',buttons['down']);
//   ...
//   buttons.OnHotKey = function(GlobContext,Self,WatchedCode){ etc }
// 
// When objects are referenced they should have a method !OnHotKey()! which takes three arguments
//   1  The context supplied to key watcher
//   2  The nominated object
//   3  The watch code
//
//   
//
// *Great feature!*
// When adding a watch this TEMPORARILY overrides any existing watches with the
//  same signature.  When that's removed the original will be exposed.
//  This means KW behaves as a stack.  Great for nesting of UI elements.  For 
//  example, if a menu has P-print and a sub-menu has P-previous the sub-menu
//  can add its watch for P then on closing remove it and the main menu will
//  get its original functionality back.
//
//. depends-on jQuery



// Helper (hence _ in name) which encapsulates a single watch
//===========================================================
class CkeyWatcher_Watch{


  // KeyCode is normally a SAC_num code but could be if not, an input to AsciiToSACcode()
  // 
  constructor(KeyCode,ObjOrFun,Context,Extra){
    if(/_\d{2,3}$/.test(KeyCode)){ 
      this.watchCode = KeyCode;
    }else{
      var x = KeyCode.split('_');
      if(x.length==1){
        this.watchCode = CkeyWatcher.AsciiToSACcode(x[0],false,false);
      }else{  
        this.watchCode = CkeyWatcher.AsciiToSACcode(x[1],x[0].includes('A'),x[0].includes('C'));
      }
      if(this.watchCode===false){
        this.watchCode = KeyCode;
      }  
    }
    //console.log('CON ',KeyCode,this.watchCode);
    
    
    if((typeof ObjOrFun == 'function')||(typeof ObjOrFun == 'object')){
      this.objOrFun = ObjOrFun;
    }else{
      throw "CkeyWatcher_Watch constructor needs an object or function.";
    }      
    this.context = Context;
    this.altOn = false;          // has Alt on its own been pressed
    this.onAltChange = null;     // function to cakk when altOn changes
    this.extra = Extra;          // optional extra 
  }
  
  
  
  // Either calls the function or the OnHotKey method of the object
  //----------------------------------------------------------------- 
  Act(){
    if(typeof this.objOrFun == 'function'){
      this.objOrFun.call(this.context,this.watchCode);
    }else{
      this.objOrFun.OnHotKey.call(this.context,this.objOrFun,this.watchCode,this.extra);
    }  
  }  
  
  // Debugging tool
  _Describe(){
    var a = (typeof this.objOrFun == 'function') ? 'Fun:'+this.objOrFun.name : 'Str:'+this.objOrFun;
    return '('+this.watchCode+')==>'+ a;
  }  
    
}



//===========================================================
class CkeyWatcher{
  
  
  // only some keys a-z,0-9 will have alt automatically added
  //  to them.  (Reason, to stop say ESC being masked by having alt added)  
  static IsAutoAltCode(KeyCode){
    return (((KeyCode>=48)&&(KeyCode<=57))||((KeyCode>=65)&&(KeyCode<=90)));
  }  
  
  // Given the *single* Ascii or key word as per .AsciiToKeyCode() 
  //  return the string key-watcher recognises
  //----------------------------------------------------------  
  static AsciiToSACcode(Ascii,AltFlag,CtrlFlag){
    var cc = CkeyWatcher.AsciiToKeyCode(Ascii);
    if(cc===false){return false;}
    var s = (c<0) ? 'S' : '';
    var a = AltFlag ? 'A' : '';
    var c = CtrlFlag ? 'C' : '';
    return s+c+a+'_' + Math.abs(cc);
  }
  

    
  // Single text character or BS, TAB, ENTER, DEL, INS, UP, DOWN, LEFT, RIGHT, HOME, END, F1...F12, SPACE  
  // to a keyboard code.  Or return false if not found.
  // Case for key words is ignored, but single characters are returned -ve if shift is required.  
  //  For example:  A gives 65 a gives -65, 5 gives 53 while % gives -53  
  // Negative values would convert into "S_65" as the key code in .AddWatch() etc for "a"
  //----------------------------------------------------------------------------------------------------
  static AsciiToKeyCode(Ascii){
    var v,k,i;
    const topSymbols = ')!"£$%^&*(';
    var c = Ascii.toUpperCase();
    
    if(Ascii.length==1){
      v = Ascii.charCodeAt(0);
      if((v>=48)&&(v<=57)){return v;}  // 0..9
      if((v>=65)&&(v<=90)){return v;}  // A..Z
      if((v>=97)&&(v<=122)){return 0-(v-32);}  // a..z
      i = topSymbols.indexOf(c);
      if((i>=0)&&(i<=10)){return 0-(48+i);}      // top row of numbers
      if(Ascii=='.'){return 190;}  //special case 
      if(Ascii=='['){return 221;}  //special case 
      // drop through to specific key lookup
      k = Ascii;
    }else{
      k = c;
    }  
    
    
		v = CkeyWatcher.c2kLookup[k];	 
    if(v){return v;}else{return false;}
  }  
  
  // object keyboard character -> decimal value  
  static get c2kLookup(){
    return {
      '|': -220 , '\\': 220,
      //'+': -61,  
      //'-': 173,
      '+': 107,  
      '-': 109,
      '=': 61,
      '{': -221,  
      '}': -219,   ']': 219,
      '~': -51,     '#': 51,
      '@': -222,   '\'': 222,
      ':': -59,     ';': 59,
      '<': -188,   ',': 188,
      '>': -190,   
      '?':  191,   '/': 111,
      '_': -173,
      'BS': 8,
			'TAB': 9,
      'ESC':27,
			'ENTER': 13 ,
			'RETURN': 13 ,
			'DEL': 46,
			'INS': 45,
			'UP': 38,
			'DOWN': 40,
			'LEFT': 37,
			'RIGHT': 39,
			'HOME': 36,
			'END': 35,
      'PGDN': 34,
      'PGUP': 33,
			'F1': 112,'F2': 113,'F3': 114,'F4': 115,'F5': 116,'F6': 117,'F7': 118,'F8': 119,'F9': 120,'F10':121,'F11':122,'F12':123,
    'SPACE':32};
  }
  
    
  static CodeToUserText(Code){
    var rv = '';
    var bits = Code.split('_');
    if(bits.length<2){return Code;}
    if(bits[0].includes('S')){rv+='Shift+';}
    if(bits[0].includes('A')){rv+='Alt+';}
    if(bits[0].includes('C')){rv+='Ctrlt+';}
    var dec = parseInt(bits[1],10);
    return rv+bits[1];
  }    
      
    
    
    
  // Create a KeyWatcher object.
  // The Context (usually this) is for running the action functions 
  // If Target is supplied then it is a DOM element, otherwise the !document! element is used
  //------------------------------------------------------------------------
  constructor(Context,Target){
    this.codeFuns = [];  
    this.stack = [];  // temporarily pushed out of way .codeFuns    
    this.context = Context;
    this.debug = false;
    this.disabled = false;
    this.catcherElement = Target || document;
    $(this.catcherElement).on('keydown',null,this,this._TestAndDo);
  }

  Push(){
    this.stack.push(this.codeFuns.slice());
    this.codeFuns = [];
    return this;
  }
  Pop(){
    if(this.stack>0){
      this.codeFuns = this.stack.pop();
    }else{
      this.codeFuns = [];
    }
    return this;
  }    
      
  
  SetAlt(Boolean){
    this.altOn = Boolean;
    if(typeof this.onAltChange == 'function'){
      this.onAltChange.call(this.context,this.altOn);
    }
  }

  SetAltChangeHandler(HandlerFun){
    this.onAltChange = HandlerFun;
  }  

  Disable(){
    this.disabled = true;
  }
  Enable(){
    this.disabled = false;
  }
  
  
  // Add an action function triggered by a key combination
  // This returns the key watcher itself so you can chain calls
  // 
  //------------------------------------------------------------------------
  AddWatch(KeyCode,ObjOrFun,Context,Extra){
    // Adds the new mapping to the front of the array
    // This may duplicate or override the identical key mapping later in the array
    // That's fine because we'll always be searching from the front
    this.codeFuns.unshift(new CkeyWatcher_Watch(KeyCode,ObjOrFun,Context,Extra));
    if(this.debug){this.DumpWatches('Add:'+KeyCode);}
    return this;
  }
  
  FindWatchIx(KeyCode){
    return this.codeFuns.findIndex(V=>(V.watchCode == KeyCode));
  }  
  
  // find watch obj or return false
  FindWatch(KeyCode){
    var w = this.codeFuns.find(V=>(V.watchCode == KeyCode));
    if(typeof w == 'undefined'){return false;}
    return w;
    
  }  
  
    
  RemoveWatch(KeyCode){
    var ix = this.FindWatchIx(KeyCode);
    if(ix > -1){
      this.codeFuns.splice(ix,1);
    }  
    if(this.debug){this.DumpWatches('Remove:'+KeyCode);}
    return this;
  }

  DumpWatches(Trigger){
    var a = this.codeFuns.map(V=>V._Describe());
    console.log('KeyWatcher '+Trigger+'\n'+a.join('\n')+'\n-------'+a.length+' watches ----');
  }
  

  // switch debuggin on/off to the console.
  // Use this to note what's going on at development time
  // NOTE This returns the keywatcher so you can chain this with AddWatches
  //------------------------------------------------------------------------
  Debugging(TrueOrFalse){
    this.debug = TrueOrFalse;
    return this;
  }

  // This is the handler which sorts out if we've got something we need to act on  
  // Return false if a handler was found and called
  // The handler is passed the event object using the context provided on construction,
  //  so for example you might have a handler  Handle(Ev){
  //    var targetElmt = $(Ev.target); ...  
  //. Event.data is this key watcher
  //------------------------------------------------------------------------
  _TestAndDo(Event){
    
    if(this.disabled){return;}
    
    var kw = Event.data; 
    if(Event.which==18){
      kw.SetAlt(true); 
      return;
    }
    
    var s = Event.shiftKey ? 'S' : '';    // make the key
    var c = Event.ctrlKey ? 'C' : '';
    // alt may be being watched so that say menus work with
    // alt THEN key.  Here we may add it in if alt has been
    // toggled on.
    var a = Event.altKey ? 'A' : '';
    if(CkeyWatcher.IsAutoAltCode(Event.which)){
      if(typeof kw.onAltChange == 'function'){
        if(kw.altOn){
          a='A';
        }
      }
    }      
    
    
    
    var k = s + c + a + '_' + Event.which;

    // handy tool for developers
    if(Event.data.debug){
      var con = k;
      if(s!=''){con+=' SHIFT';}
      if(c!=''){con+=' CTRL';}
      if(a!=''){con+=' ALT';}
    }
    
    // lookup function and if found call it
    var w = Event.data.FindWatch(k);
    if(w){
      Event.preventDefault();
      Event.stopPropagation();
      Event.returnValue=false;
      if(Event.data.debug){console.log('KeyWatcher ACTED ON');}
      w.Act();
      return false;
    }else{
      return true;
    }    
  }

}