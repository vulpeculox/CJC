//=========================================================
// MENU 
//=========================================================





//                                                                                                                       
//    .oooooo.                                                                   ooooooooo.                              
//   d8P'  `Y8b                                                                  `888   `Y88.                            
//  888          ooo. .oo.  .oo.    .ooooo.  ooo. .oo.   oooo  oooo               888   .d88'  .ooooo.  oooo oooo    ooo 
//  888          `888P"Y88bP"Y88b  d88' `88b `888P"Y88b  `888  `888               888ooo88P'  d88' `88b  `88. `88.  .8'  
//  888           888   888   888  888ooo888  888   888   888   888               888`88b.    888   888   `88..]88..8'   
//  `88b    ooo   888   888   888  888    .o  888   888   888   888               888  `88b.  888   888    `888'`888'    
//   `Y8bood8P'  o888o o888o o888o `Y8bod8P' o888o o888o  `V88V"V8P' ooooooooooo o888o  o888o `Y8bod8P'     `8'  `8'     
//                                                                                                                       
//                                                                                                                       
//     


// defines a row of a menu
class Cmenu_Row{

  // Create a new menu row
  // Text is display with optional alt-hot-key preceded by underscore eg.  *_Save*
  // DisplayMode is one of V,H,G or L  for Visible, Hidden, greyed and list.
  //  List is used by .SetList() to route events to an external function.
  // Action
  //      !function! which is executed in the global context
  //   or !string()! or !string(args)! which is the literal onClick text
  //   or !string!  (no brackets) is the name of a sub-menu
  //. Action as a function is simplest and most reliable, but you may find
  //.  issues with the sequencing of configuratings etc.
  //. The string() pattern may have issues when being called via a hotkey as only
  //.  the global window scope is recognised.
  // Context is the Cmenus object that holds everything (and has keyWatcher)
  //---------------------------------------------------------------------------
  constructor(Text,DisplayMode,Action,Hint,Context){
    this.text = Text;      // caption after html highlights etc
    this.rawText = Text;   // captionas-supplied
    this.options = [];
    // possibly hack list of options
    var rx = /\[.*\]/;
    var ma = rx.exec(this.text);
    if(ma){
      this.options = ma[0].substr(1,ma[0].length-2).split('|');
      this.text = this.text.replace(ma[0],'#OPT#');
    }  
    
    this.id  = 'men_row_'+ Math.floor(Math.random() * 99999999 );  // label used by dom/event code to refer to this
    this.hotKey = '';
    this.hint = Hint;
    this.menus = Context;
    this.actionIsFun = false;
    this._DecodeTextForHotKey();

    this.SetDisplayMode(DisplayMode);   // L,V,H or G list/visible/hide/grey   

    
    // -------- Action decode ------------
    this.action = Action;
    this.actionType = '?';
    if(typeof Action == 'string'){
      this.actionType = Action.endsWith(')') ? 'str' : 'men';
    }else{
      if(typeof Action == 'function'){
        this.actionIsFun = true;
        this.actionType = 'fun';
      }else{  
        throw "Cmenu_Row has unsuitable Action.";
      }
    }
        
    // Prepare the on-click code    
    var oc='onclick="';
    switch(this.actionType){
    case 'str' : oc+= this.action+';"'; break;
    case 'fun' :  if(this.displayMode=='L'){
                    oc+= this.menus.id+'.ListClick(event);"';
                  }else{
                    oc+= this.action.name+'(event);"';
                  }  
                  break;
    case 'men' : oc+= this.menus.id+'.Extend(event,\''+this.action+'\');"'; break;    
    }
    this.onClickStr = oc;    
  }

  get option(){
    var rv = (this.options.length>0) ? this.options[0] : undefined;
    return rv;
  }
  
  // TestOpt can be partial match
  IsOption(TestOpt){
    var rv = false;
    var o = this.option();
    if(typeof o == 'string'){
      rv = o.includes(TestOpt);
    }
    return rv;
  }
  
  // Replace the current option with the next and stick
  //  this at end of options.  For a boolean this has the 
  //  effect of a simple switch.
  // Returns the new option
  //----------------------------------------------------
  CycleOption(){
    var o = this.options.shift();
    this.options.push(o);
    this.DomElement().parent().html(this.Html());
    return this.options[0];
  }    
  
  // change the state to H,V or G
  SetDisplayMode(NewMode){
    var nm = NewMode.toUpperCase()[0];
    if('GVHL'.includes(nm)){
      this.displayMode = NewMode;
    }else{
      throw 'Cmenu_Row.SetState needs H,G,L or V not ('+NewMode+')';
    }      
  }  
  
  _DecodeTextForHotKey(){
    // possibly decode a hot-key
    var rexUscore = /(_\w)/;
    var hota = rexUscore.exec(this.text);
    if(hota){
      var hk = hota[1].substr(1);
      this.hotKey = CkeyWatcher.AsciiToSACcode(hk.toLowerCase(),true,false);
      this.text = this.text.replace(rexUscore,'<span class="hotKey">'+ hk + '</span>'); 
    }
  }
  
  
  ChangeText(NewText,IsCurrent){
    if(IsCurrent){this.RemoveHotKey();}
    this.text = NewText;
    this._DecodeTextForHotKey();
    // all done... unless current menu
    if(IsCurrent){
      this.DomElement().parent().html(this.Html());
      if(this.menus.keyWatcher.altOn){    // might have to specially add-in alt-highlight
        this.DomElement().find('.hotKey').addClass('hotLive');
      }
    }  
  }
  
    
    
  // Return <li><span id hint class onclick>text poss arrow</span>
  //------------------------------------------------
  Html(){
    var id = 'id="'+this.id+'" ';
    var txt = this.text;
    if(this.options.length>0){txt = txt.replace('#OPT#',this.options[0]);}
    var cl = '';
    var oc = this.onClickStr;
    var t = ' title="'+this.hint+'" ';
    var ext = (this.actionType=='men') ? '<span class="m1 f120 black">&rtrif;</span>' : '';
    if(this.displayMode=='G'){
      cl = ' disabled ';
      oc='';
    }else{
      this.AddHotKey();
    }  
    cl = ' class="button'+cl+'" ';
    return '<li><span '+id+t+oc+cl+'>'+txt+ext+'</span>';
  }  
  
  OnHotKey(WatchedCode){
    switch(this.actionType){
    case 'str' : window[this.action](); break;   // can never happen
    case 'fun' : this.action.call(); break;
    case 'men' : this.menus.Extend.call(this.menus,this.id,this.action); break;    
    //@@@case 'lst' : this.menus.ListClick.call(this.menus,this.id,this.action); break;    
    }
  }
  
  DomElement(){
    return $('#'+this.id);
  }  
  
  FakeClick(WatchedCode){
    this.DomElement().click();
  }

  AddHotKey(){
    if(this.hotKey){
      //console.log('>',this.actionType,this.action);
      switch(this.actionType){
      case 'fun' : this.menus.keyWatcher.AddWatch(this.hotKey,this.action,this); break;
      case 'str' : this.menus.keyWatcher.AddWatch(this.hotKey,this.FakeClick,this); break;
      case 'men' : this.menus.keyWatcher.AddWatch(this.hotKey,this,this); break;
      }  
    }
  }  
  
  RemoveHotKey(){
    if(this.hotKey){
      this.menus.keyWatcher.RemoveWatch(this.hotKey);
    }
  }  
  
  TestHotkey(SACwatchCode){
    return (this.hotKey == SACwatchCode);
  }  
    
  
  
  
}  
  

//                                                                                                                       
//                                                                                                                       
//    .oooooo.                                                                                                           
//   d8P'  `Y8b                                                                                                          
//  888          ooo. .oo.  .oo.    .ooooo.  ooo. .oo.   oooo  oooo   .oooo.o                                            
//  888          `888P"Y88bP"Y88b  d88' `88b `888P"Y88b  `888  `888  d88(  "8                                            
//  888           888   888   888  888ooo888  888   888   888   888 `"Y88b.                                             
//  `88b    ooo   888   888   888  888    .o  888   888   888   888  o.  )88b                                            
//   `Y8bood8P'  o888o o888o o888o `Y8bod8P' o888o o888o  `V88V"V8P' 8""888P'                                            
//                                                                                                                       
//                                                                                                                       
  
    

// All the menus for a page.
// This manages their order and catches keys
//======================================================
class Cmenus extends Cindex{
  
  constructor(Id){
    super('id');
    this.id = Id;    
    this.selfReference = Id;//Mung(Id);     // how is this known in the DOM
    this.idChain = [];  // Ids of menus on show.  top-most on end
    this.keyWatcher = new CkeyWatcher(this);
    this.keyWatcher.SetAltChangeHandler(this.HandleAltChange);
    this.altMenuShowFun = null;
    this.burger = null;   // active element that will trigger menu show
    this.dragMenu = null;   // DOM element being dragged
    this.dragHead = null;   // title bar of dragMenu
    this.t2pX = 0;  // relationship between top left of dragMenu 
                    // and pointer at the time we clicked
    this.t2pY = 0;

  }

  // Probably the result of ESC being trapped by the key watcher
  EscapeToClose(){
    this.CloseCurrent(true);
  }
  
  // what's the top-most menu on show (or false)
  //--------------------------------------------
  get _currentId(){
    if(this.idChain.length >0){
      return this.idChain[this.idChain.length-1];
    }else{
      return false;
    }
  }    
  
  get _currentMenu(){
    var id = this._currentId;
    if(id){
      return this.Get(id);
    }else{
      return false;
    }
  }    
   
  Menu(Id){
    return this.Get(Id);
  }    
   
   
  CloseAll(){
    this.CloseCurrent(true);
  }

   
  CloseCurrent(All){
    // this menu
    var cmId = this._currentId;
    if(cmId===false){return;}
    $('ul#'+cmId).remove();         // Clear DOM
    var m = this.Get(cmId);       // tidy hot keys
    m.Close();
    
    this.keyWatcher.Pop();//RemoveWatch(CkeyWatcher.AsciiToSACcode('ESC'));
    this.idChain.pop();
    // parent (if any) menu
    cmId = this._currentId;  
    if(cmId){
      $('ul#'+cmId).removeClass('shadeOver');
      if(All){
        this.CloseCurrent(All);
      }  
    }  
  }  
   
  // Add a single menu configuration or an array of them 
  Add(MnuCfg){
    var ma = Array.isArray(MnuCfg) ? MnuCfg : [MnuCfg];
    while(ma.length>0){
      var mc = ma.shift();
      var m = new Cmenu(mc,this);
      super.Add(m,true);
    }
  }
  
    
  Show(Id,X,Y){
    var m = this.Get(Id);
    if(m){
      $('body').append(m.HTML());
      this.idChain.push(m.id);
      this.keyWatcher.Push().AddWatch(CkeyWatcher.AsciiToSACcode('ESC'),this.EscapeToClose,this);
      m.AddHotKeys();
      m.ShowAt(X,Y);
    }
  }
  
      
  // EvOrId is either an event (keydown) or a string which is the id
  //  of the menu item being hot-keyed.
  //-----------------------------------------------------------------
  Extend(EvOrId,SubId){
    var clickedOn,clickX,clickY;
    if(typeof EvOrId == 'string'){
      clickedOn = $('#'+EvOrId);
      var coo = clickedOn.offset();    // top,left
      var cow = clickedOn.width();
      clickX = coo.left + cow;
      clickY = coo.top + 5;
    }else{
      clickedOn = $(EvOrId.target);
      clickX = EvOrId.pageX;
      clickY = EvOrId.pageY;
    }  
    var thisMenu = clickedOn.parents('ul');  // DOM
    var subMen = this.Get(SubId);
    if(subMen === false){
      console.log('SUB MENU ('+SubId+') NOT FOUND');
      return;
    }  
    
    thisMenu.addClass('shadeOver');
    this.Show(SubId,clickX,clickY);
  }  
  

  // Replace text in a menu
  // Deals with hotkeys and any necessary redisplay
  //---------------------------------------------------------------
  Substitute(MenuId,Existing,New){
    var m = this.Get(MenuId);
    if(m){
      m.Substitute(Existing,New);
    }
  }
  
  // Use the event's target to get the id and
  // from there the row.  Must be current menu
  //-----------------------------------------
  FindClickedRow(Event){
    Event.stopPropagation();
    
    var clickedOn = $(Event.target);
    var id = clickedOn.attr('id');
    if(!id){                                   // clickedOn might be a sub-element
      clickedOn = clickedOn.parents('[id]');   // of the main button span.  So find
      id = clickedOn.attr('id');               // the id of the parent button
    }  
    var cm = this._currentMenu;
    if(cm){  // can't possibly fail!
      var cr = cm.GetRow(id);
      if(cr){return cr;}
    }
    return false;
  }    
    
  // The alt key has been pressed.
  // This means either
  // (a) If no menu on show then show top
  // (b) if menu on show then adjust css for highlighting keys
  //----------------------------------------------------------  
  HandleAltChange(AltState){
    if(this._currentMenu===false){
      if(this.burger){
        this.DoBurgerClick();
      }  
    }else{  
      var hots = $('.hotKey');
      if(AltState){
        hots.addClass('hotLive');
      }else{
        hots.removeClass('hotLive');
      }      
    }  
  }
  
  // Where are the clickable symbols in the DOM to get the top
  // menu displayed.  Typically a three layer burger image.
  //------------------------------------
  SetBurger(Selector,TopMenuId){
    if(this.burger){                        // possibly remove previous linkage
      this.burger.off('click',this.DoBurgerClick);
    }  
    this.burger = $(Selector).first();
    this.burger.on('click',this,this.DoBurgerClick);
    this.topMenuId = TopMenuId;
  }  

  // showing the top menu
  //------------------------------------
  DoBurgerClick(Ev){
    var ms = (Ev) ? Ev.data : this;
    ms.CloseCurrent(true);   // clear all showing already
    var off = ms.burger.offset();
    ms.Show(ms.topMenuId,off.left+20,off.top+40);
  }  

  //------------- dragging ---------------------------------------------------------
  // clicked on menu heading. Start drag
  StartDrag(Ev,Id){
    var clickX = Ev.pageX;
    var clickY = Ev.pageY;
    var clickedOn = $(Ev.target);
    var mnu = clickedOn.parent('ul');
    var off = mnu.offset();
    this.dragMenu = mnu;
    this.dragHead = clickedOn;
    this.t2pX = clickX - off.left;  // relationship between top left and pointer
    this.t2pY = clickY - off.top;   // at the time we clicked
    clickedOn.on('mousemove',this,this.DoDrag).on('mouseup mouseleave',this,this.EndDrag);
    clickedOn.addClass('grabbing');
    return false;
  }

  EndDrag(Ev){
    var m = Ev.data;
    m.dragHead.removeClass('grabbing');
    m.dragHead.off('mousemove',m.DoDrag).off('mouseup mouseleave',m.EndDrag);
    m.dragHead = null;
    m.dragMenu = null;
    return false;
  }  
  
  DoDrag(Ev){
    var m = Ev.data;
    var clickX = Ev.pageX;
    var clickY = Ev.pageY;
    var offL = clickX - m.t2pX;
    var offT = clickY - m.t2pY;
    m.dragMenu.offset({left:offL,top:offT});
    return false;
  }  
    
  //--------------- modify on the fly -------------------
  
  SetCaption(MenuId,Caption){
    var m = this.Get(MenuId);
    if(m){
      m.caption = Caption;
      this.Refresh(MenuId);
    }  

  }

  Refresh(MenuId){
    var cmId = this._currentId;
    if(cmId == MenuId){
      this._currentMenu.Refresh();
    }
  }    
  
  // See Cmenu.Setlist()
  //-------------------------------  
  SetList(MenuId,StartingAt,List,Callback,Hint){
    var m = this.Get(MenuId);
    if(m){m.SetList(StartingAt,List,Callback,Hint);}
  }  

  // We get here when clicking on a list item.  
  // Call the callback set in .SetList()
  //------------------------------------------
  ListClick(Ev){
    var m = this._currentMenu;
    if(m){
      if(typeof m.listCallback == 'function'){
        //var r = m.menus.FindClickedRow(Ev);
        m.listCallback(Ev);
      }
      Ev.stopPropagation();
      Ev.returnValue=false;
    }      
  }
  
  // change the state of a row in a specified menu
  // RowIxOrText is an integer or identifying text
  //----------------------------------------------  
  SetDisplayMode(MenuId,RowIxOrText,NewState){
    var m =  this.Get(MenuId);
    if(m){m.SetDisplayMode(RowIxOrText,NewState);}
  }    


  
}          
  



//    .oooooo.                                                                                                           
//   d8P'  `Y8b                                                                                                          
//  888          ooo. .oo.  .oo.    .ooooo.  ooo. .oo.   oooo  oooo                                                      
//  888          `888P"Y88bP"Y88b  d88' `88b `888P"Y88b  `888  `888                                                      
//  888           888   888   888  888ooo888  888   888   888   888                                                      
//  `88b    ooo   888   888   888  888    .o  888   888   888   888                                                      
//   `Y8bood8P'  o888o o888o o888o `Y8bod8P' o888o o888o  `V88V"V8P'                                                     
//       

// A collection of CmenuRow items with a standard UI and 
//  variable position
//======================================================
class Cmenu{

  //---------------------------------------------
  constructor(Config,Menus){
    this.id = Config.id;                 // Id as used in DOM and code (simple \w string please!)
    this.caption = Config.caption;       // caption
    this.autoClose = Config.autoClose;   // automatically cloase after pick
    this.parentId = Config.parentId;     // who is the parent
    this.preload = Config.preload;       // optional function before show
    this.rows = Config.rows.map(function(V){
      return new Cmenu_Row(V[0],V[1],V[2],V[3],Menus);
    },this);
    this.charsWide = this.caption.length;
    this.menus = Menus;
    this.listCallback = null;  // might be (string)(global)@@@@@ method to call when a list item is clicked
    this.onShowTextReplace = Config.onShowTextReplace;
  }    

  
  // lookup rows to find first starting with supplied Text
  // NB Any underscore used to set hot-key must be included
  // This works on the original 'bare' text
  //---------------------------------------------
  _FindIxByText(Text){
    return this.rows.findIndex(R=>R.rawText.startsWith(Text));
  }

  // Replace existing text in some undefined row with
  //  new text.  This works on the current actual (htmlised) text
  //----------------------------------------------------
  Substitute(Existing,New){
    var isCurrent = (this.id == this.menus._currentId);
    var mr = m.RowByText(Existing);
    if(mr){mr.ChangeText(New,isCurrent);}
  }    
  
  AddHotKeys(){
    this.rows.forEach(R=>R.AddHotKey());
  }  

  // Create a new row (or replace the same text with another action)
  // Text is display with optional alt-hot-key preceded by underscore eg.  *_Save*
  // State is one of Cmenu.VISIBLE Cmenu.HIDDEN Cmenu.GREY
  // Action is a function
  //---------------------------------------------
  SetRow(Text,State,Action,Hint){
    var r = new Cmenu_Row(Text,State,Action,Hint);
    var ix = this._FindIxByText(Text);
    if(ix>=0){
      this.rows[ix]=r;
    }else{
      this.rows.push(r);
    }
    this.Refresh();
  }    

  // change the state of a row
  // RowIxOrText is an integer or identifying text
  //----------------------------------------------  
  SetDisplayMode(RowIxOrText,NewState){
    var ix = (typeof RowIxOrText == 'string') ? this._FindIxByText(RowIxOrText) : RowIxOrText;
    this.rows[ix].SetDisplayMode(NewState);
    this.Refresh();
  }    
    
  
      

  
  // Set some or all of the rows to match a given list.
  // List is an array of strings.
  // Callback takes the event as an argument (Everything can
  //  be found from this eg by myMenus.FindClickedRow(Ev) )
  // Hint is optional and the same for all.
  // Note: The Callback is also called at the close of the menu
  //  with the argument "CLOSE".  You might use this to deal with
  //  state changes in bulk after all changes have been made.  So
  //  typically the first line of the callback would be:
  // | if(Event=='CLOSE'){...  
  //--------------------------------------
  SetList(StartingAt,List,Callback,Hint){
    this.listCallback = Callback;
    this.rows.splice(StartingAt);
    List.forEach(function(V){
      var r = new Cmenu_Row(V,'L',Callback,Hint,this.menus);
      this.rows.push(r);
    },this);
    this.Refresh();
  }  

  // return   
  GetList(){
    var ls = this.rows.filter(R=>R.displayMode=='L');
    return ls.map(function(L){
      var txt = L.text;
      if(txt.includes('<span')){
        txt = txt.split('>')[1].split('<')[0];
      }
      return [L.option,txt];
    });
  }  
    
    
  
  // un-highlight the alt-hotkeys
  //--------------------------------
  RemoveHotKeys(){
    var a = this.rows.filter(R=>(R.displayMode !='H'));
    a.forEach(R=>R.RemoveHotKey());
  }

  // if we have a preload function then call it.
  // Note. Async function is not a good idea!
  //-------------------------------------------
  DoAnyPreload(){
    if(typeof this.preload == 'function'){
      this.preload.call(this);
    }
  }    
      
      

  // Html for all li elements.  Note: If !.preload! is a function then
  //  call that first.
  //------------------------------------------------------------------
  _Lis(){
    this.DoAnyPreload();
    //if(typeof this.onShowTextReplace == 'function'){
    //  this.onShowTextReplace.call(this);
    //}  
    var a = this.rows.filter(V=>(V.displayMode !='H'));
    var cw = this.caption.length;
    a.forEach(function(V){
      if(V.text.length>cw){cw=V.text.length;}
    });
    a = a.map(V=>V.Html());
    this.charsWide = cw;    
    var omd = 'onmousedown="'+this.menus.selfReference+'.StartDrag(event,\''+this.id+'\');" ';
    return '\n<li '+omd+'>'+this.caption+'\n'+a.join('\n');
  }
  
  // Complete Html for ul
  //-----------------------------------------
  HTML(){
    return '<ul id='+this.id+' class=menu>'+ this._Lis()+'</ul>';
  }
  
  // Call Refresh when rows have changed and the menu /might/ be
  //  on show.  There is no harm calling this if it isn't on show.
  //--------------------------------------------------------------
  Refresh(){
    var ul =  $('ul#'+this.id);
    if(ul.length>0){
      ul.html(this.HTML());
    }
  }    
      
  
  Close(){
    /*  why???
    if(typeof this.listCallback == 'function'){     // possibly action a close after list
      this.listCallback('CLOSE');
    }   */
    if(this.parentId){
      $('#'+this.parentId).removeClass('shadeOver');
    }
    this.menus.keyWatcher.SetAlt(false);  // clear the alt watching status
  }     
      
  
  Hide(){
      console.log('hide');
    $('#'+this.id).hide();
  }

  ShowAt(X,Y,WithData){
    this.withData = WithData;
    var page = $('body'); 
    var po = page.offset();    // top,left
    var pw = page.width();
    var ph = page.height();
    var cx = X - po.left;
    var cy = Y - po.top;
    var m = $('ul#'+this.id);
    m.show();
    var mWidth = m.outerWidth();
    var mHeight = m.outerHeight();

    // position menu according to space available
    var mLeft = ((cx + mWidth) > pw) ? pw-mWidth : cx;
    var mTop  = ((cy + mHeight) > ph) ? ph-mHeight : cy;
    mLeft = (mLeft<0) ? 0 : mLeft;
    mTop = (mTop<0) ? 0 : mTop;
    var css = {'top' : mTop+'px','left' : mLeft+'px'}; 
    m.show().css(css);
  }
  
  GetRow(Id){
    var r = this.rows.find(V=>V.id==Id);
    if(typeof r == 'undefined'){return false;}
    return r;
  }  
    
  
}
  
