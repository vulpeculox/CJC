Title:   CJC
Purpose: JSON for ES6, classes, functional objects with other elements 'fixed'
Licence: MIT
Author:  Peter Fox
Contact: cjc@vulpeculox.net
Website: vulpeculox.net/misc/jsjq/CJC

Also on github.

This is the full developer package with additional API documentation and testing page.
Yes please test and hack, but don't forget to document.
By all means contact the author after checking developer discussion on the web page.

To be honest, I find github a bit of a complicated who-ha.  If you don't then you're
very welcome to apply for the job of librarian/code curator or mention it to somebody
you know who fancies a responsible and detailed job.

If you think the way the code works code could be improved then suggesting your thrust
by email is probably the most effective start.

If you really like cool code and want to take on maintenance and more sophisticated
testing then that's doable too.  I'm a brute-force engineer rather than a fluent
systems software guy.

Also I have other similar projects which would benefit from better skills and experience.
Peter Fox







